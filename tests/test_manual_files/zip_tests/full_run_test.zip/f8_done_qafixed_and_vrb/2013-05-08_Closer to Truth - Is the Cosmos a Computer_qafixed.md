## metadata
last updated: 02-21-2024 by Randy after Mae (quote check only) after Randy - added header and timestamp links
link: https://www.youtube.com/watch?v=UohR3OXzXA8
transcript source: whspmerge
length: 5:44

## content

### qa

QUESTION: Is information the most fundamental element of the universe?
TIMESTAMP: [0:29](https://www.youtube.com/watch?v=UohR3OXzXA8&t=29)
ANSWER: I'm opposed to the view _that the cosmos is a computer or that information is the most fundamental element of the universe._ I think it misses the point, it misses the lesson of what is really important about the link between computation and physics. Computation, and with it information is indeed very fundamental, but it's not the most important thing. It's not the thing that the universe is made of, as it were. So there are variants of this theory, like the universe is a computer, or that the universe is a program running in God's computer, or something like that. __It seems to me that those theories all miss the point about the universality of computation, which is the way that computation links with physics, through the existence of a universal computer, a computer that can compute anything that can be computed, and can therefore simulate any physical object. If this computer were outside the universe, it wouldn't be very remarkable. You can always imagine some kind of computer with some kind of way of operating that would simulate any laws of physics, no matter what they were. And so you lose the fact that our actual laws of physics are intimately connected with computation.__ What is the connection? It's not that there's a computer outside the universe, it's that we can make universal computers inside the universe. That is a token of the computability of the laws of nature. It's the reason for the unreasonable effectiveness of mathematics in the natural sciences. It's the reason for the existence of life and the possibility of science. Those things are explained by the existence of computers in the universe, but wouldn't be explained if the universe was in a computer.
EDITS:
TOPICS: it-from-bit, unreasonable effectiveness, simulation
STARS: 4
ALTERNATE QUESTION: Is the cosmos a computer?

QUESTION: How do you account for the growing sense that the fundamental nature of reality is information, that "it comes from bit"?
TIMESTAMP: [2:39](https://www.youtube.com/watch?v=UohR3OXzXA8&t=159)
ANSWER: _Regarding the view that it comes from bit,_ it's perhaps a natural mistake to make given the fundamentalness of computation. Perhaps the reason for the mistake is that we are accustomed to explaining things in reductionist terms. So instead of explaining things in terms of space, time, atoms, and forces, we explain it in terms of qubits, or bits, or qubits, and computations. But that is not an advance in explanation, for the reason that I just said. And the real connection is the computability of the laws from within the universe. *IN-LINE: And so that makes information part of the process of the universe, but not sitting at the fundamental nature of the universe?* The existence of information is indeed fundamental, but it's not fundamental in the reductionist sense. It's fundamental in the sense that there is a law of nature that the universe is computable, or that a universal computer exists.
EDITS:
TOPICS: it-from-bit, computation, reductionism
STARS: 

QUESTION: Does information exist and operate on multiple levels, including the most fundamental level?
TIMESTAMP: [4:05](https://www.youtube.com/watch?v=UohR3OXzXA8&t=245)
ANSWER: _Regarding whether information exists and operates on multiple levels, including the most fundamental level,_ computers are emergent objects. There is no such thing as a computer at the subatomic level. Or if you did make a computer at the subatomic level, it wouldn't be universal, and therefore wouldn't be fundamental. The fundamental computers are the ones that are universal, and they are the ones that are quite big. They're like the computers that we actually have and use in everyday life. _Information does operate on the most fundamental level,_ but that, as I have argued, can't underlie. That's just an alternative way of talking about atoms.
EDITS:
TOPICS: information, computation
STARS: 

QUESTION: Does information exist at every level of the hierarchy of the laws of nature or only at the fundamental level?
TIMESTAMP: [5:01](https://www.youtube.com/watch?v=UohR3OXzXA8&t=301)
ANSWER: Information exists at every level, including at the fundamental level of atoms. Whether an atom is there or not is a fundamental thing. But at the level of laws of nature, information comes in at a particular level of explanation, namely the level at which there are computers, and the level at which there are people thinking about stuff. That level of explanation. *IN-LINE: How then does that way of thinking allow us to understand reality better?* Because almost all ways that the laws of physics could be do not have the property that a universal computer could exist.
EDITS:
TOPICS: information, computation, physics
STARS: 

