## metadata
last updated: 02-21-2024 by Randy after Randy - did qafixed
link: https://www.youtube.com/watch?v=GBc6vj5-wko
transcript source: dgwhspm
length: 8:56

## content

### qa

QUESTION: How do we understand ultimate reality and what are the elements of the fabric of reality?
TIMESTAMP: [0:24](https://www.youtube.com/watch?v=GBc6vj5-wko&t=24)
ANSWER: _The fabric of reality_ is about what's fundamental, and more specifically, about the most fundamental things that we know. I don't attempt to find ultimate reality because I think that's a kind of chimera. We always should start with problems and start with what we know and then try to make it more fundamental than that. And what I call fundamental, a fundamental idea, is one that is needed in the explanation of many other ideas or many other phenomena and so on. And the most fundamental ones we know are basically the ones that are needed in the explanation of practically everything. And I wrote the Fabric of Reality because I realized that the most fundamental theories, which there are four that I picked out as being the most fundamental, formed a sort of unified fabric of reality, a conception of the world, where none of them could be understood without the other three. And they were the quantum physics, which is my actual field, and then the theory of evolution, the theory of computation, and the theory of knowledge, which is usually not even considered part of science, but those were the four strands.
EDITS:
TOPICS: reality, FOR, four strands
STARS: 

QUESTION: From the book The Fabric of Reality, how do the four strands fit together?
TIMESTAMP: [2:00](https://www.youtube.com/watch?v=GBc6vj5-wko&t=120)
ANSWER: _From the book The Fabric of Reality, the four strands_ seem at first sight to be different kinds of thing. Three out of the four seem to be tied to us humans or to life on Earth or something, while the fourth is universal. But the closer you look at these four theories, branches of knowledge, strands of the fabric of reality, the more you realize that you can't understand any of them without the others. They're all intimately related.
EDITS:
TOPICS: FOR, four strands
STARS: 

QUESTION: What is a quick synopsis of quantum physics in the context of being one of the four strands of the Fabric of Reality?
TIMESTAMP: [2:33](https://www.youtube.com/watch?v=GBc6vj5-wko&t=153)
ANSWER: Quantum physics is one of the two fundamental theories of physics. It is the language in which all other theories are written. The other fundamental theory is Einstein's theory of relativity, which describes space and time. Quantum theory is the language that all other theories in physics are expressed in and it sort of constrains the kinds of ideas that one can express within physics. It's the deepest and most successful theory.
EDITS:
TOPICS: quantum, four strands
STARS: 4

QUESTION: What is a quick synopsis of evolution in the context of being one of the four strands of the Fabric of Reality?
TIMESTAMP: [3:08](https://www.youtube.com/watch?v=GBc6vj5-wko&t=188)
ANSWER: The theory of evolution is the basic theory of emergent properties. It's how large objects can be understood in terms that do not follow from their low-level definitions in terms of atoms. And so we have laws like the principle of evolution which is a rigorous law of nature and in terms of which Darwin solved one of the fundamental mysteries of nature but it cannot be expressed in terms of atoms. So that's the theory of evolution.
EDITS:
TOPICS: evolution, four strands
STARS: 4

QUESTION: What is a quick synopsis of computation in the context of being one of the four strands of the Fabric of Reality?
TIMESTAMP: [3:53](https://www.youtube.com/watch?v=GBc6vj5-wko&t=233)
ANSWER: The theory of computation is the theory of what processes in nature are independent of or transcend the material substance that they are embodied in. So for example, I can say I had an idea last year and now I'm telling it to you. And that idea is an abstract entity that is, first of all, instantiated in the brain, then it's instantiated in movements of my mouth, then in vibrations of air molecules and so on. And it can be instantiated in ink on paper and an enormous variety of things. But in order to understand any of those transitions, you have to understand that what is affecting things, what is moving things here, is the information itself, not its instantiations. And the general theory of how information is processed in the world is the theory of computation.
EDITS:
TOPICS: computation, four strands
STARS: 4

QUESTION: What is a quick synopsis of knowledge in the context of being one of the four strands of the Fabric of Reality?
TIMESTAMP: [5:01](https://www.youtube.com/watch?v=GBc6vj5-wko&t=301)
ANSWER: Knowledge is the kind of information that can do things, or solve problems as we would say at the human level. But in these terms, Adaptations in living things are also a form of knowledge. So DNA embodies knowledge, human brains embody knowledge. Books and computers and the internet all embody knowledge. And the thing about the knowledge that makes it fundamental is that if you think of any kind of transformation of a physical system, you know, from hot to cold or from a block of marble into a statue and so on, you think about all possible transformations that are permitted by the laws of physics, the overwhelming majority of those only happen if the right knowledge is present. So from the point of view of what can be transformed into what, it's practically all the theory of what knowledge can do, and that is why knowledge is a fundamental thing in the physical world.
EDITS:
TOPICS: knowledge, four strands
STARS: 4

QUESTION: Does knowledge need to have a purpose, teleology, or meaning to be considered knowledge?
TIMESTAMP: [6:17](https://www.youtube.com/watch?v=GBc6vj5-wko&t=377)
ANSWER: _Regarding knowledge having a purpose or meaning,_ with the benefit of hindsight, one can determine that knowledge has a meaning because it's the meaning that keeps it in existence. One way of expressing the fact that knowledge is information that does something is that it's the kind of information which once it is embodied in a certain type of physical system, it tends to remain so. And in biology, that happens because its rivals die. *IN-LINE: DNA is a good example, representing the fitter of the species.* Exactly, or rather the fitter of the genes. With human knowledge an idea remains embodied in things like books and brains to the extent that it does something, like it enlightens people or it allows the physical world to be manipulated or whatever, but it has to have some kind of use.
EDITS:
TOPICS: knowledge, meaning
STARS: 

QUESTION: What are the implications of the four strands (quantum physics, evolution, computation, knowledge) of the Fabric of Reality?
TIMESTAMP: [7:20](https://www.youtube.com/watch?v=GBc6vj5-wko&t=440)
ANSWER: In my first book, in The Fabric of Reality, I just wanted to say that these four strands are fundamental in this sense, and I wanted to say that you can't understand any of them without the other three, and that all of them have been kind of underestimated in that they have been accepted as the right explanation in their own field, but they haven't been taken seriously as a component of people's worldview. So that, for instance, people accept quantum theory, but they don't accept its parallel universes implications. Other people accept the universality of computation, but they don't accept that this implies that it's possible to program artificial intelligence and so on. *IN-LINE: By integrating all of these into basically a theory of at least current reality, how do you feel about that now with some distance to your original creation?* __It has made me think of the world in a much more unified way.__ And that's why I eventually came around to writing the second book, which is applying this fabric of reality to various issues which, on the face of it, like the four strands themselves, don't look as though they have anything to do with each other or with the four strands and yet the closer you look the more integrated they are and the more they do have to do with each other.
EDITS:
TOPICS: FOR, four strands, unity
STARS: 4

