## metadata
last updated: 02-21-2024 by Randy after Bert dq replace after Randy
link: https://www.youtube.com/watch?v=3eEffbjzNwE
transcript source: whspmerge
length: 10:21

## content

### qa

QUESTION: What does the concept of explanation mean in the context of understanding reality and predicting future human developments?
TIMESTAMP: [0:24](https://www.youtube.com/watch?v=3eEffbjzNwE&t=24)
ANSWER: An explanation is a statement of what is there in reality, and how it works and why, basically. But the important distinction is between a good explanation and a bad explanation, because explanations are two a penny, but good explanations are extremely hard to come by, and this is what the growth of knowledge is actually about. So a good explanation is one that is hard to vary while still explaining what it purports to explain. So shall I give an example? Suppose you're watching a conjuring trick, and you're trying to explain what's happening. Now an example of a bad explanation would be, "Well, it's actually magic." And the reason that that's a bad explanation is that you could apply that same explanation to absolutely anything, including to the conjuring trick happening a different way, or to a conjuring trick not happening, and so on. So that claim about reality, that it really is magic, is not actually an explanation, or if you like, it's a bad explanation. Another example of a bad explanation, just to show you that a bad explanation doesn't necessarily have to be false, it just may be completely inadequate, is to say, "Well, the conjurer did something." So that may be enlightening for a person who believes in magic, to tell them that in fact it was the conjurer that did it, but it doesn't explain the trick. And if we take by analogy with the laws of physics, and trying to explain things in the natural world, we could say, "What is the origin of species? What is the origin of adaptations in the biological world?" You could say, "Well, it's just caused by atoms." Now that's true enough, but it doesn't explain. The explanation is Darwin's theory of evolution, or rather the modern neo-Darwinist theory of evolution.
EDITS: 
TOPICS: explanation, magic
STARS: 5

QUESTION: How does the concept of good and bad explanations apply to the reductionist approach in science?
TIMESTAMP: [3:10](https://www.youtube.com/watch?v=3eEffbjzNwE&t=190)
ANSWER: Reductionism is a prejudice. It's historically understandable because the physical sciences, and especially physics, were the ones that developed fastest. And it so happens that the best explanations in physics have been, at any rate, from the ground up, from space and time, elementary particles, that kind of thing. But it's never been the case, even within physics, let alone in other sciences, that all good explanations are reductionist. And in fact, my basic principle, if you like, that we should be looking for good explanations, which I think is the foundation of scientific rationality, implies that we must not have that prejudice, because if we do find an explanation that's on a higher level of emergence, say, and we find a fundamental law at the higher level of emergence, and it's a good explanation, then it's simply irrational to reject it just because it doesn't have the form which, historically, we have been taught is the one we should pursue.
EDITS:
TOPICS: explanation, reductionism, emergence
STARS: 4

QUESTION: What is meant by different modes of explanation?
TIMESTAMP: [4:24](https://www.youtube.com/watch?v=3eEffbjzNwE&t=264)
ANSWER: _Regarding different modes of explanation,_ with deep explanations, it's nearly always the case that when somebody finds a new and much deeper theory, it's not only a better explanation that they've found, it's also a better mode of explanation. So for example, in physics, Einstein's explanation of gravity in terms of curved space-time was not just a new explanation of gravity, that would have been something like Newton's laws, but instead of an inverse square law, an inverse 2.003 or something law. It's not like that. It's a different kind of explanation. It's saying that space and time, which in Newton's theory are immutable background entities that aren't part of the theory, become, in Einstein's theory, dynamical objects which buck and weave and explain all sorts of things apart from just the motion of planets.
EDITS:
TOPICS: explanation
STARS: 5

QUESTION: What is bad philosophy?
TIMESTAMP: [5:48](https://www.youtube.com/watch?v=3eEffbjzNwE&t=348)
ANSWER: __Bad philosophy is a subset of bad explanations.__ False philosophy is not harmful. In fact, error is the standard state of human knowledge. We can expect to find error everywhere, including in the theories that we think are, that we most cherish as true. But there has grown up, especially since the Enlightenment, ironically, since good explanations have begun to take over, bad explanations have become worse and bad philosophy has dominated the field of philosophy for many decades. Bad philosophy is philosophy whose effect is to close off the growth of knowledge in that field. So it's the kind of thing that says not just so-and-so is true when in fact it is false, but you mustn't think about so-and-so, or it's bad to investigate so-and-so. Logical positivism is a prime example of a bad philosophy.  *IN-LINE: Which restricts your ability to even address questions as meaningless because it's not either sense data or logic or something like that.* Exactly right. So it's saying that trying to understand what the physics is of unobserved objects is unscientific, according to positivism. Now that means really that it's trying to reduce us to an anthropocentric worldview, rather like the medieval worldview, because it's saying that the only things that are worthy of study are human experiences. But of course human experiences are themselves to be understood in terms of unexperienced things like neurons. So the whole philosophy collapses, and in addition it declares itself to be meaningless because this distinction that it draws applies to itself as well and rules out positivism as a worthy subject of study.  *IN-LINE: What are other examples of bad philosophy?* The ones that are closest to my mind are the ones that have impinged on physics. So logical positivism was one example of that. But __when, in recent times, statistical analysis of experimental results has started to use terminology that assumes that certain things will never be worth studying. So for example, the very term explanation has come to mean a mathematical formula. They say a mathematical formula explains the results. But since the results are anthropocentric and they are not reality, they're just a tiny sliver of reality through which we are trying to understand the unobserved reality, this idea that a formula is an explanation prevents real explanations from being discovered. They are ruled illegitimate.__
EDITS: combined several segments
TOPICS: bad philosophy, positivism, statistics
STARS: 5

QUESTION: What is the antidote to circular reasoning of bad philosophy?
TIMESTAMP: [9:15](https://www.youtube.com/watch?v=3eEffbjzNwE&t=555)
ANSWER: I think that all progress, historically and today, comes from the quest for good explanations, that is explanations that are hard to vary while still accounting for what they purport to account for. One of the reasons I like this principle, is that not only does it explain what the criterion for success is in science, where it leads to things like the principle of testability of theories because a test constrains the explanation so that it's hard to vary, but it also applies outside physics in philosophy, in epistemology, in metaphysics, and so on. The same thing applies and even beyond that in political philosophy, moral philosophy, and aesthetics. The same principle applies everywhere and draws a distinction between ideas that have a chance of making progress and ideas that have no chance of making progress.
EDITS: 
TOPICS: bad philosophy, progress, explanation, reason
STARS: 4

