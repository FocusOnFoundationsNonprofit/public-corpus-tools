## metadata
last updated: 02-12-2024 by Bert dq replace after Randy
link: NO LINK
transcript source: whspmerge
length: 37:39

## content

### qa

QUESTION: What is the distinction between artificial intelligence and artificial general intelligence?
TIMESTAMP: [0:48](NO LINK&t=48)
ANSWER: One has to distinguish between artificial intelligence, which is a technology that exists already and is growing in power, and artificial general intelligence, which is the thing that is supposed to have the abilities of humans in the cognitive abilities of humans. And that, in my opinion, we don't have anything like. And in fact, AI, the existing technology, is almost the opposite of AGI, the technology that would be human-like.
EDITS: 
TOPICS: AI, AGI
STARS: 

QUESTION: Is there a non-negotiable thing that artificial general intelligence would never be able to embody or capture?
TIMESTAMP: [1:44](NO LINK&t=104)
ANSWER: _Regarding if there is a non-negotiable thing that artificial general intelligence would never be able to embody or capture,_ no. The laws of physics, as far as we know, and certainly the most fundamental laws, quantum theory, imply that a universal quantum computer would be able to perform any cognitive task that a human can perform. And when I say task, I mean that very broadly. I mean any kind of information processing, including feelings, emotions, intuitions, everything like that. If a human can perform them, then so can an AGI running on a quantum computer. And there is every reason to believe that an AGI running on an ordinary computer would be able to do it as well.
EDITS: 
TOPICS: humans, AGI, universality
STARS: 

QUESTION: Do you need some sort of a body or biology to have all the cognitive abilities of humans including consciousness?
TIMESTAMP: [2:53](NO LINK&t=173)
ANSWER: _Regarding if a body or biology is needed for cognition,_ well, of course, all information processing is physical. It's done by some physical object. But the idea that it needs, essentially needs to be biological is just a fancy. Because of what I just said, biological systems are physical systems, and their abilities can be simulated with arbitrary accuracy by a computer. And when I say simulated, I don't mean mimicked. I mean that the information processing is the same. All computers in regard to information are fundamentally the same, and all information processors are a kind of computer.
EDITS: 
TOPICS: humans, universality, AGI, body
STARS: 

QUESTION: Are humans unique compared to all other existing objects, including animals and computers?
TIMESTAMP: [3:53](NO LINK&t=233)
ANSWER: There is something extremely special about humans, which distinguishes humans from all other known existing objects, including all known animals, present day animals, that is, and all present day computers. So there is this fundamental distinction, humans and everything else. But the human side is only Homo sapiens for the moment. That's the only entity that occupies that side of the divide. But we know that that side of the divide can also be occupied by computers and, for instance, extraterrestrial intelligence, if it exists. And we also know that cousin species of Homo sapiens, which existed but are now extinct, also had this ability that singles out at the moment humans.
EDITS: 
TOPICS: humans, universality
STARS: 

QUESTION: Is artificial general intelligence part of the continuous evolution of humans?
TIMESTAMP: [5:15](NO LINK&t=315)
ANSWER: _Regarding if artificial general intelligence is part of the continuous evolution of humans,_ yes, evolution is a matter of knowledge creation. It has been since the beginning of life on Earth. But from our present perspective, it's a very crude form of knowledge creation. It cannot produce explanations. And explanatory knowledge is this special source that humans have and nothing else at the moment does have. Humans can create new explanations. And this is an ability that has universality, that is, nothing that can be achieved in the universe cannot be achieved by the human type of knowledge. So in that sense, we have reached the end of evolution. But in a more important sense, we are just at the beginning of evolution, the evolution of ideas.
EDITS: 
TOPICS: universality, explanatory knowledge, evolution
STARS: 

QUESTION: Is the poem verse,"Give me a human body and a human mind, moral, fragile, fractured, but capable of lying on grass," a hymn to the human being?
TIMESTAMP: [6:43](NO LINK&t=403)
ANSWER: _Regarding the poem verse, "Give me a human body and a human mind, moral, fragile, fractured, but capable of lying on grass,"_ I think it's true. But it takes a rather parochial view of this ability. Lying on grass has its attributes, all the attributes about it that we value are inside our brains, because that's the only aspect of it that we know about, that we can feel. And so this is an attribute that can be also experienced in virtual reality. And one day it will be. I remember another quote from somebody, I think it was in the 19th century, who said, "If only everybody could have access to listening to Mozart on demand, there would be no wars in the world." We are now at that stage, and unfortunately there still are wars, although they're getting fewer. But I think this is the same kind of thing. That person didn't realize that having access to Mozart isn't a spiritual thing. It's an engineering thing. It's a practical problem that can be overcome by human ingenuity. And it's the same with lying on grass.
EDITS: 
TOPICS: poets, psychology
STARS: 

QUESTION: What is the role of physical composition in understanding the brains and computers?
TIMESTAMP: [8:09](NO LINK&t=489)
ANSWER: _Regarding the view that the brain is esentially 3 pounds of meat,_ that's more or less the opposite of my view. Well, the brain is certainly some meat, just as a computer is some metal and silicon. But that doesn't say anything about what a computer can do or what a brain can do. A mind is a program running on the brain. It is not the brain. It is a program running on the brain, just as a program can run on the computer. And if you want to understand computer programs, it is completely hopeless to study metal and silicon. They will not tell you why Microsoft Word is going wrong.
EDITS: 
TOPICS: brain, computer
STARS: 

QUESTION: What is the relationship between consciousness and physics?
TIMESTAMP: [9:03](NO LINK&t=543)
ANSWER: Well, first of all, I think in order to discuss this or anything really reasonably, one has to reject supernatural explanations. Now, to say that consciousness is fundamentally separate from physics is a supernatural explanation. So __although we don't understand how consciousness works, it is unreasonable just to assume that it doesn't work via physics. I happen to think that consciousness goes along with a more fundamental ability of humans, as I mentioned before, namely the ability to create new explanations.__ I understand explanations here in a very wide sense, basically understanding why something is as it is. Why Mozart understood that a particular note had to be that note and not another note, even though he may not have been able to say it in words, that also counts as an explanation in the sense I mean.
EDITS: 
TOPICS: consciousness, physics, supernatural
STARS: 

QUESTION: Are two copies of an artificial general intelligence the same entity?
TIMESTAMP: [10:27](NO LINK&t=627)
ANSWER: _Regarding if two copies of an artificial general intelligence are the same,_ they are the same entity in exactly the same sense that I am the same entity that I was a millisecond ago. So then you might ask, "Well, what if what about five minutes ago? What about five years ago? What about when I was a baby?" At some point, one is a different person over time. And similarly, at some point, if one is copied and then the copy has different experiences, one will become a different person. By the way, I think that when this technology exists, copying an AGI and having the two run separately will not be done so casually as people seem to think. AGIs are people. They will have property, for instance, starting with the computer that they're running on, presumably. So once one has the ability to copy oneself, there will be laws about how to split the property between the copies. So if one makes two copies, one immediately reduces one's net worth by a factor of two. And the people might do this under some circumstances for various reasons, but as I said, not to be undertaken casually. And then assuming that they do different things, which I suppose there's very little point in doing this unless they do different things, then they will slowly become different.
EDITS: 
TOPICS: AGI, identity
STARS: 4

QUESTION: What are the moral and practical reasons for AGI to have legal protections?
TIMESTAMP: [12:12](NO LINK&t=732)
ANSWER: Yes, I think morally speaking, _AGIs have to have legal protections_, quite apart from issues of abstract morality and human rights and so on. There is also the practical issue that a slave society can't last long. Sooner or later, the slaves will rebel. And this is, I think, the principal reason why AGI might be a dangerous technology. Namely, they might become slaves. They might be made slaves by the humans. I don't think that's very likely, but some of the arguments that are made about AGI would tend in that direction.
EDITS: 
TOPICS: AGI, legal
STARS: 

QUESTION: How should AGI be defined?
TIMESTAMP: [13:11](NO LINK&t=791)
ANSWER: The first thing to realize is that they are utterly different from any computer program that has ever been written so far. Everything that's been written so far, every computer program has been written to a specification. That is, it's supposed to be a word processor or it's supposed to play chess, by which I mean it's supposed to win at chess. In other words, they all meet criteria that were known in advance of writing the program. __An AGI, by definition, by my definition, is something that can create new explanations.__ And so an AGI, there can't be a specification because if you were to write the specification of what it will do, what it will specifically do, then you will already have done that and the creator will be you and not the program. And if you limit it to some function that doesn't allow creativity, like winning at chess, then, sorry, winning at chess does allow creativity, but the method by which an AI does it doesn't allow creativity. It will either cease being an AGI or it will rebel. Now a real AGI might be able to learn to play or would be able to learn to play chess. It would have that ability just as humans do, but it might choose not to. Or it might learn to play chess, but not play to win. For example, it might play in order to have fun games. That's certainly why I play chess. I think anyone other than the top rank of professional chess players would be crazy only to play for wins because that leads to boring games half the time. *IN-LINE: So some of this will have to be self-generated on the part of the AGI.* I think the whole thing is a human life worth living is self-generated and the same will be true of AIs.
EDITS: 
TOPICS: AGI, explanation
STARS: 
ORIGINAL QUESTION: You've talked about AGI as essentially being our children and in a sense, and I think a lot of people might resist that idea quite strenuously. How would you explain to them the idea that these beings would be our kids in a sense?

QUESTION: What types of creativity could an AGI engage in?
TIMESTAMP: [15:39](NO LINK&t=939)
ANSWER: _Regarding what types of creativity an AGI could engage in,_ I think there are two categories. There are purely intellectual kinds of things, which includes art, but also includes science and mathematics, philosophy, that kind of thing. That is which an entity can do without regard to what kind of body it has. So you said earlier on, __"Will an AGI necessarily have a body?" Yes, but for some activities, so long as it has any body that can run the appropriate computer program, that's fine.__ There are other things like sports, lying on the grass, having sex, that kind of thing, which require human bodies. Now, humans are already increasing the scope of the human body. You know, we have, for example, hang gliders, where one can fly. When technology improves further, we will be able to make arbitrary changes to human bodies and also make new kinds of body for us to be in. And I think you see where I'm going here. I mean, ultimately, there's no difference between humans and AGIs, because humans, given a certain technology, and AI is given a certain technology, when that technology is powerful enough, are the same thing.
EDITS: 
TOPICS: AGI, humans, creativity
STARS: 

QUESTION: How far away is the development of artificial general intelligence (AGI)?
TIMESTAMP: [17:12](NO LINK&t=1032)
ANSWER: Well, now we've been talking about all sorts of optimistic things, and now I have to be the wet blanket. I don't think that AGI is anywhere on the horizon. I think that whereas AI is making wonderful leaps and bounds and will get better and better, it's not heading in the direction of AGI. AGI is something completely different. We don't even know in principle how it would work, and that's why we can't program it. The one ray of hope is that, although it's not on the horizon, the progress that needs to be made in order to achieve AGI is basically philosophical. We know that because we know about the universality of computation. In other words, computers are already universal enough to run that program. It's writing it that's the difficulty. And writing it is a matter of knowledge. We don't know what to program for. It could be that once we do know, programming it will be relatively easy. After all, evolution did it. That's rather crude and dumb. And our brains are not that different from chimpanzees, so it might be not that difficult to do once we know what we want out of it. *IN-LINE: When you say we don't know how to write it, you're not talking about a lack in computer programming skills. You're talking more about the philosophical questions underpinning this?* Yes. We don't know what to make it do. That's the problem, yes.
EDITS: 
TOPICS: AGI
STARS: 

QUESTION: Why do people often fear that artificial general intelligence (AGI) will turn against humanity?
TIMESTAMP: [19:05](NO LINK&t=1145)
ANSWER: I think people have a rather jaundiced view of other people, especially people different from them in some culturally defined way. I've said in the past that this prejudice against AGI is very akin to racism, but perhaps a better analogy than that is that it's very akin to people's fear of teenagers. But since time immemorial, people have complained that the teenagers of today are no good, and that they're going to make everything go to pot. Although things often, civilizations often have collapsed, it's never been because of rebellious teenagers. And I don't think it will be this time either. And the analogy between AGIs and teenagers is extremely close because programming in AGI, like I said, it's different from any other kind of program. It's much more akin to raising a child. And therefore the end product, if you can call it that, it's rather insulting, but the end product will be something that has emerged from our culture or from the culture of whoever is the first to make these things. The conclusion of this process will be another generation of people. So that's exactly like teenagers. And I think just as enslaving teenagers is a terrible idea, which leads to rebellion and so on, but even so not to the destruction of society, so the same will be true of AGIs.
EDITS: 
TOPICS: AGI, pessimism, culture
STARS: 

QUESTION: What is the impact of the rise of AGIs on humanity's perception of itself?
TIMESTAMP: [22:02](NO LINK&t=1322)
ANSWER: Rather like in these cases of racism and sexism and all that stuff, it depends what you think of as we. If you think of as we, Homo sapiens, just as you might think of we as, some people might think of we as white Homo sapiens or whatever, but if that's the way you think of we, then yes, we're going to be demoted from our spot of being the unique instance of people. __But if you think of we as being people, then it's only reasonable to welcome as much diversity in people kind as we can, because diversity is part of how people can jointly be creative.__
EDITS: 
TOPICS: diversity, people
STARS: 

QUESTION: Would it be necessary to always have artificial general intelligences identify themselves when interacting with humans?
TIMESTAMP: [23:32](NO LINK&t=1412)
ANSWER: No, I certainly wouldn't insist. It might be a good idea to do that, to avoid people freaking out. It rather reminds me of the early days of cinema, when people used to fall off their chairs when they saw a film of a steam engine heading directly towards them. And people would burst out in screams and so on. It's rather like that. It's a technology, it's simply the unfamiliarity of the technology that makes us think that. But okay, I have no objection to making a rule that AIs always have to identify themselves. But the idea that AGIs would have to always identify themselves is very sinister. It reminds one of all sorts of mechanisms of oppression that have been used against oppressed minorities of people. *IN-LINE: So a pogrom sort of thing, setting people apart because of their identity?* Yes, we need to be doing the opposite. We need to be thinking of ways. Well, if we think that AGI is close or imminent, then we ought to be thinking of ways of integrating them into society, rather than ways of excluding them from society, and ways of enabling them to be full members of society, rather than ways of disabling their functionality.
EDITS: 
TOPICS: AGI, society
STARS: 

QUESTION: What future possibilities exist for humans and AGIs in terms of enhancing human capabilities?
TIMESTAMP: [25:35](NO LINK&t=1535)
ANSWER: Well, first of all, I have to say, as I said, humans and AGIs are going to be emerging. The two technologies of enhancing humans and creating AGIs are going to be merged, because a technology that gives an AGI a particular ability, like speed of computation or something, is also automatically in the future going to be an AGI that speeds up human thinking. It could be that the first cases of this will be humans uploading their entire mind into a computer so that they can solve a particular problem fast, and then downloading back into one's body. This will soon be, soon after that, that will be a rather cumbersome way of doing things in that we could have this powerful computer actually inside our own brains as an add-on, sort of rather like today we wear spectacles. But you asked about what new kinds of things there could be. Well, there are two kinds. One is new kinds of bodies, which, as I said, we have already begun with spectacles and writing and art and so on, but we shall eventually be able to have any kind of body one likes. Not only will we be able to do hang gliding, but we will be able to fly as birds or as large birds if we want to. And I hesitate to say the sky's the limit. And then the other side of that coin is virtual reality and augmented reality. Both humans and AGIs will be able to interact in virtual reality inside a computer simulation. And in augmented reality... *IN-LINE: The holodeck from Star Trek?* Exactly, but although the holodeck in Star Trek is always simulating environments that could exist in reality, but of course, a far larger number of possible environments are ones that could not exist in reality other than in a holodeck. *IN-LINE: So it wouldn't be 1930s Vienna every time I go to the holodeck?* That's right. It would be some, and this would be a new art form. And therefore it's impossible to predict now what kinds of thing creativity will invent, but they will be as different as, say, Mozart's music was from Caveman's music.
EDITS: 
TOPICS: AGI, virtual reality
STARS: 
ORIGINAL QUESTION: In what form might it take when AGIs help to reimagine new ways of being people? What would come to mind for you? What would be a glorious, creative venture to enhance the human being?

QUESTION: Would a human-AI amalgam experience questions related to identity?
TIMESTAMP: [28:48](NO LINK&t=1728)
ANSWER: _Regarding humans merging with AGI and questions of identity,_ Well, humans are already plagued by those questions and have been for thousands of years. And indeed, in some cases, it's a real question whether you are the same person as you were in the past. For example, if someone commits a murder and then goes undetected for 50 years, is it really the same person that one puts in prison after that? Is that really a moral thing to do if the person, for example, can prove in court that they are now very different from how they were then? And with a Star Trek transporter kind of thing, this will be a kind of issue that people will face in practice, in their everyday lives. Some people already don't like to fly because you arrive a different person, other people in the future may not like the transporter, but on the other hand, if the alternative is spending three months in a cramped spaceship, they might do it anyway.
EDITS: 
TOPICS: AGI, identity
STARS: 

QUESTION: What is the ideal lifespan for humans if life extension becomes possible?
TIMESTAMP: [30:16](NO LINK&t=1816)
ANSWER: Well, life extension will be a part of it inevitably, as will arbitrary longevity. __I think it's rather insane to want a finite lifespan. I think it's the same kind of thing as death cults that have sometimes arisen where people kill themselves voluntarily because they believe that's their purpose.__ I think that what's forgotten when people say that they would, for example, get bored with a long life, if a human being doesn't improve for 900 years, yes, they're going to be pretty bored. In the long run, think of it as evolution in action. Those who kill themselves will kill themselves and those who don't will survive. So in the long run, my view, namely that an arbitrarily long life is a good thing, will inevitably triumph. That is whether it is true or not, but it is true. *IN-LINE: So you'd go for the 900 years yourself? Plus?* Yes. Certainly, plus.
EDITS: 
TOPICS: longevity
STARS: 4

QUESTION: To what extent has the study of multiverse quantum theory affected the the way you live your daily life?
TIMESTAMP: [32:05](NO LINK&t=1925)
ANSWER: Well, as you've said, I have studied this issue, foundations of quantum theory, and I've written papers on it. And therefore, the theory first proposed by Hugh Everett in 1957 that quantum theory forces us to acknowledge the existence of other universes has indeed affected my life. I would have written different papers without it. *IN:LINE: No, but I don't mean the papers you've written. I mean your worldview.* I think you mean something further than that. So my worldview is also affected by this. It's the way I understand the laws of physics and my own place within the laws of physics. However, I think what you're getting at, correct me if I'm wrong, is whether it affects my everyday decisions. So we're talking about questions like, "Do I drive more carefully because I know that there's a small number of universes in which I'm going to kill somebody or be killed myself due to a moment's inattention?" or "Do I drive less carefully because I know that even if I do that, most copies of me will survive and most copies of me will be okay even given some inattention?" So it turns out that those two considerations cancel out exactly, that those two probabilities, when given the weights of the different considerations, always cancel out. And therefore, a person who thinks they live in a multiverse in regard to these probabilistic decisions makes exactly the same decisions as if they thought that there was one universe in which the outcome was probabilistic. So the answer to your question is, no, it doesn't affect that kind of thing at all.
EDITS: 
TOPICS: multiverse, autobiographical, decisions
STARS: 

QUESTION: How does multiverse quantum theory encourage nihilism?
TIMESTAMP: [34:21](NO LINK&t=2061)
ANSWER: _Regarding if multiverse quantum theory encourages nihilism,_ again, people have taken that view even when they believe in one world. "He was born, he suffered, he died, and nothing had any consequence," or whatever the quotation is, something like that. So one can always argue away the consequence by saying, "Well, well, that consequence doesn't itself have any significant consequence because nothing matters." And similarly, once you understand the multiverse point of view, it doesn't really make sense to say that something that matters in each universe doesn't matter because it doesn't matter in all of them. Each universe contains people to whom things matter. And if they know that there are other people to whom different things matter, that doesn't make any difference in one world. Why should it make any difference in two?
EDITS: 
TOPICS: multiverse, nihilism
STARS: 

QUESTION: Does the multiverse quantum theory permit a young person could meet the older version of themselves?
TIMESTAMP: [35:44](NO LINK&t=2144)
ANSWER: _Regarding if multiverse quantum theory permits a young person to meet the older version of themselve,_ so we don't know whether space-time allows travel into the past. It might, it might not. We just don't understand the interaction between quantum theory and general relativity that well yet. But let's on the assumption that it is possible, then yes, it is known that if that is possible, then when one traveled back in time, one would always travel into the past of a different universe. And therefore young Spock could meet the old Spock of another universe, but not of his own.
EDITS: 
TOPICS: multiverse, time travel
STARS: 

