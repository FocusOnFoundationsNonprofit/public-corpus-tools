## metadata
last updated: 02-15-2024 by Randy after Mae (quote check) after Randy - added header and timestamp links
link: https://www.youtube.com/watch?v=YD-capWJMyc
transcript source: whspmerge
length: 6:40

## content

### qa

QUESTION: Is it viable to look for deep underlying principles that can be applied across different scientific disciplines?
TIMESTAMP: [0:39](https://www.youtube.com/watch?v=YD-capWJMyc&t=39)
ANSWER: I'm not sure that the existing approaches to general systems theory is the actual way of integrating all sciences, but I think the idea that all sciences are integrated by their principles at the fundamental level is correct and has to be correct. An obvious principle that unites all science is just the principle of testability, that the truth about nature takes the form of testable theories. I think that the principle of testability is a special case of a much more general principle, the principle of good explanation, a good explanation being one that is hard to vary while still accounting for what it purports to account for.
EDITS:
TOPICS: testability, unity, science
STARS: 

QUESTION: What distinguishes science from other forms of human knowledge?
TIMESTAMP: [1:46](https://www.youtube.com/watch?v=YD-capWJMyc&t=106)
ANSWER: What characterizes science within the realm of human knowledge, is that science has testable theories and the truths about the physical world consist of testable theories. But this idea of a good explanation reaches beyond science into even, you mentioned aesthetics, even aesthetics. It's customary to say so-and-so is a matter of taste to mean there is no truth of the matter. But I think that cannot be so. I think there is a truth of the matter. It really is objectively true that, for example, Mozart produces better sounds, more aesthetic sounds than cavemen banging rocks together. And although we may not have a sophisticated enough knowledge of aesthetics, especially in explicit form, to know which is which, we know that it is there. The distinction between better or worse exists objectively in aesthetics as it does in morality and in every other area of philosophy.
EDITS:
TOPICS: knowledge, science, explanation, testability, morality, aesthetics, objectivity
STARS: 

QUESTION: Can aesthetic judgments, such as comparisons between composers like Mozart, Beethoven, or Brahms, be made objectively?
TIMESTAMP: [3:11](https://www.youtube.com/watch?v=YD-capWJMyc&t=191)
ANSWER: _Regarding objectively comparing Mozart to Beethoven,_ we do not know yet what the better way of analyzing these things is. I think it must be, and for the following reason. You cannot separate these fields, science and aesthetics and so on, totally from each other. As Jacob Bronowski said, for example, "You can't do science, you can't make progress in science unless you also have certain moral values such as tolerance, respect for the truth," and so on. So these things are matters of moral philosophy, but they are essential to science as well. And therefore, they are essential to how the physical world is put together. So these different fields are only separated from each other for pragmatic reasons. If you look in sufficiently fine detail at the boundary between all these different fields of philosophy and between philosophy and science, you find they merge into each other and they can't be separated.
EDITS:
TOPICS: aesthetics, objectivity, unity
STARS: 

QUESTION: Are there any other principles beyond testability and good explanation that can unify the sciences?
TIMESTAMP: [4:30](https://www.youtube.com/watch?v=YD-capWJMyc&t=270)
ANSWER: Good explanation is the fundamental _principle that can unify the sciences,_ as far as is known at present. I don't believe that there's ever an absolute foundation to be found to knowledge, but I think the deepest thing we know at the moment is the principle of good explanation, which implies all sorts of things. About science it implies the principle of testability. In politics it implies Popper's criterion that institutions should be constructed in such a way that governments and policies can be removed without violence and so on.
EDITS:
TOPICS: explanation, science, politics
STARS: 

QUESTION: Does an explanation need to have a quantitative comparison as a requirement?
TIMESTAMP: [5:35](https://www.youtube.com/watch?v=YD-capWJMyc&t=335)
ANSWER: _An explanation does not need to have a quantitative comparison as a requirement._ Galileo said that "The laws of physics are written in the language of mathematics," but the laws of morality are not. And the laws of aesthetics are not. Probably aren't. We don't know much about the laws of aesthetics.
EDITS:
TOPICS: explanation, aesthetics
STARS: 

QUESTION: Is it possible to apply rational analysis to aspects of human society, such as politics or sociology, that are not subject to quantitative analysis?
TIMESTAMP: [6:07](https://www.youtube.com/watch?v=YD-capWJMyc&t=367)
ANSWER: _It is possible to apply rational analysis to aspects of human society, such as politics or sociology, that are not subject to quantitative analysis._ Rational analysis and objective truth, whether or not it's quantitative. The aspiration of general systems theory is definitely right. And in all these fields there is such a thing as objective truth to be found. And that is part of what will link them, but whether the actual ideas in general systems analysis are currently right, I doubt.
EDITS:
TOPICS: rationality
STARS: 
