## metadata
last updated: 02-12-2024 by Bert dq replace after Created QA
link: https://youtu.be/2-8Hw0Myerw
transcript source: whspmerge
length: 27:08
note: mp3 length is [27:03](https://youtu.be/2-8Hw0Myerw&t=1623)

## content

### qa

QUESTION: What makes a good explanation?
TIMESTAMP: [2:18](https://youtu.be/2-8Hw0Myerw&t=138)
ANSWER: __The idea of an explanation being good is my solution to what you might call the centuries old problem of "How come things work? How come science works?" and all previous methods of trying to understand things like what makes the stars shine and so on just didn't work.__ They just didn't make any headway at all. And the standard answer for that in the case of science has been that we have testable theories now and previously theories were untestable. So you couldn't ever tell the difference between rival theories and so you could never make progress. But I think for various reasons that's inadequate because, for example, many myths are also testable, but they're still not capable of making progress. And my idea is that a good explanation is one that accounts for something in reality, purports to account for something in reality where it is hard to vary. That's the key thing. In other words, a slightly different account would not account for that thing as well. And so that's a good explanation. The nice thing about the idea of a good explanation is that within science it explains why testability is the criterion for good science. But good explanation applies beyond science as well. It applies in philosophy and politics and morality and aesthetics and everything. And I try to cover all those things in the book.
EDITS: 
TOPICS: science, good explanation, hard to vary
STARS: 5

QUESTION: How can "hard to vary" be applied as a criterion for good explanations in fields where testability is not possible?
TIMESTAMP: [3:56](https://youtu.be/2-8Hw0Myerw&t=236)
ANSWER: _Regarding fields where testability is not possible_, there testability is just a special case of hard to vary. So for example, if you had an idea that no one's allowed to steal except you and that's the moral thing, then the thing is that theory is easy to vary because as a moral explanation it's just as good as no one's allowed to steal except me or no one's allowed to steal except you and me and so on. And so countless variations of that idea, all with different exceptions, and none of those exceptions have a better moral explanation than any of the others. Whereas the idea that no one should steal doesn't make an exception, doesn't have to explain the exception and therefore it's a better moral explanation. One of the nice things about this critical worldview, which by the way isn't mine, it's due to the philosopher Karl Popper originally, I just applied it to this idea of good explanations, is that no criterion of criticism is excluded a priori. So you can exclude something but all of them have to contribute to this good explanation feature. So the idea that everyone should steal also has this property that it's hard to vary, but it doesn't account for the thing it's supposed to account for because if everyone could steal, that would have obvious practical disadvantages like running out of things to steal. *IN-LINE: Sure everyone just shift things around ad infinitum.* Yes it's true. It's discussed in the book, by the way, in a little cameo appearance by Generi Socrates who suggests this very idea.
EDITS: 
TOPICS: good explanation, hard to vary, testability
STARS: 

QUESTION: Why are the majority of theories, even if testable, are never actually tested?
TIMESTAMP: [5:50](https://youtu.be/2-8Hw0Myerw&t=350)
ANSWER: _Regarding good explanations coming through experience rather than from evidence to theory_, I argue that that is wrong. And that really what happens is that the validation via being a good explanation comes first. And only in the rare and fortunate case where we have more than one good explanation do we then apply, well in the case of science, do we then apply experimental testing. So the overwhelming majority of theories, even testable theories that you could think of, are never tested because they are bad explanations. And the example I gave in my first book was what about the theory that eating a kilogram of grass will cure the common cold. Well the thing is that's a perfectly testable theory, but no one will ever test it because it is a bad explanation. There is nothing that goes with it that would distinguish between that and the theory that 1.1 kilograms of grass will cure the common cold or 0.9 or whatever. And therefore you could never know when you had tested it. In general, by the way, it's impossible to test any theory that doesn't come with an explanation. One of the things I criticize in the book is theories in the less hard sciences, shall we say, in sciences like psychology and so on, where one just makes a hypothesis about how humans are without an underlying explanation for why they are like that. And those theories I think can't truly be tested even though in their form they may resemble testable theories.
EDITS: 
TOPICS: good explanation, theory, experience
STARS: 

QUESTION: Is there a limit to what we can know?
TIMESTAMP: [7:29](https://youtu.be/2-8Hw0Myerw&t=449)
ANSWER: I argue that there isn't _a limit to what we can know_ or rather there are limits imposed by things like mathematics and the laws of physics themselves. So it's possible that we shall never be able to know in the case of physics, we shall never be able to know what Julius Caesar ate for his last meal before he was assassinated. And what we shall always be able to do is solve problems. So the issue of what Julius Caesar ate for his last meal will never be something that keeps anyone awake at night. Conversely, any of the things that are capable of keeping a person awake at night, worrying about them, are soluble. And they are soluble by creating knowledge and knowledge is created by trying to create better explanations by criticizing and varying existing explanations.
EDITS: 
TOPICS: limits, knowledge
STARS: 

QUESTION: How are understanding the world and controlling it connected according to David Deutsch?
TIMESTAMP: [8:28](https://youtu.be/2-8Hw0Myerw&t=508)
ANSWER: _Regarding understanding the world and controlling it being connected_, there's a deep connection built into nature. And in the book _The Beginning of Infinity_ I try to argue why this must be so. A connection between understanding the world and controlling it. On the face of it, those are two very different things. You may understand why an asteroid is heading towards the earth and going to obliterate us. You may be able to work it out down to the last decimal place, but that in itself doesn't enable you to prevent it. But this deep connection says that with enough knowledge, understanding always is connected with the corresponding control. And that's why science is linked with technology. And that's why the unlimited nature of science, which to deny that is essentially to believe in the supernatural, that the unlimited scope of science leads to an unlimited scope of technology, which means that things which are problematic to us are always going to be soluble with sufficient technological knowledge, such as disease and death and the ability to travel in space and so on.
EDITS: 
TOPICS: science, technology, knowledge
STARS: 4

QUESTION: How has the relationship between technology development and science explanations evolved over time?
TIMESTAMP: [9:47](https://youtu.be/2-8Hw0Myerw&t=587)
ANSWER: _Regarding technology preceding the science explanation,_ this used to be much more true than it is today, and it's becoming ever less true. As both science and technology become more sophisticated, it's becoming more and more a case of working out why something must work and then building it. A very good example of this is in the science of medicine, where let's say a hundred years ago, the mode of action of medicines was basically unknown. We were lucky if we were right about the idea that a particular medicine does work, but we certainly didn't know much about how it works. Now today it's increasingly becoming the other way around. That is, there's a whole science developing of a designer pharmacology, where we first understand the mechanism of a disease, then we conjecture what kind of chemical would interrupt the progress of that disease, then we design a chemical, and only then do we ever try it. In other words, after we have the explanation. The more sophisticated science and technology get, the more it is the case that these rules of thumb type knowledge, which are really uncreatively generated, are being superseded by creatively generated good explanations.
EDITS: 
TOPICS: technology, science, explanation
STARS: 

QUESTION: It's sort of difficult then to see how the general model then fits into the humanities and economics.
TIMESTAMP: [11:14](https://youtu.be/2-8Hw0Myerw&t=674)
ANSWER: __Economics is a difficult case because it is sort of half science and half philosophy. In science we must have testable theories, and in philosophy it's a terrible mistake to require testable theories. So economics has sort of got itself into a tangle by confusing the two.__ But a more extreme case, and so I don't actually discuss economics in the book, though I do discuss political philosophy, but there is the matter of aesthetics, where almost everybody would say that what is beautiful or ugly is just a matter of personal taste, and calling it a matter of taste has been taken to be synonymous with saying that there is no objective truth of the matter. But I have an argument in the book that there must be an objective truth of the matter, and the argument is drawn from the co-evolution of flowers and insects. Basically the notion of beauty on which, or attractiveness, on which flowers and insects have co-evolved and converged, we can understand from the theory of evolution why they have evolved, the flowers to generate a particular pattern to meet a particular criterion, and insects to use that same criterion to decide what flowers to visit. It's easy to understand that via the ordinary theory of evolution, but the mystery then is, "Why do humans also reliably find that same thing attractive when we didn't have that co-evolution?" I go through various possibilities and eventually conclude that the only reasonable explanation of this is that the easiest way to do this signaling between different species was to hit upon an objective criterion of beauty and implement that. And that's why humans also find flowers beautiful, and so it's the flowers and the insects and the humans and no one else. I think you can only explain this via the theory that this beauty is objective. *IN-LINE: So that the universe actually has a criteria for what is beautiful.* Exactly. Strangely, the idea that that should be so runs counter to the prevailing, what can I call it, the prevailing rational worldview. But I think that there's no escaping it. And this all ties in, once you realize that this is so, it ties together a lot of things that have been known or suspected in any case, but people haven't known how to fit them in to the worldview. For example, we know that elegance is an excellent guide to true theories in science, that is the ones before we test them. Now it has been remarked often, many a beautiful theory has been slain by an ugly fact. But nevertheless, beauty in theories is a much better guide than just random chance would dictate. And why is that? Well that's hard to explain if beauty is simply a matter of arbitrary human or cultural taste. But it's easy to explain if beauty is objective, because then it's a matter of objective truth, what is an elegant theory. And objective truths are all related to each other, just like scientific truths all are. That's a special case of it.
EDITS: 
TOPICS: economics, aesthetics, flowers
STARS: 3

QUESTION: Is the scientific process of discovering truth a straightforward and clean process, and does it lead to a final truth?
TIMESTAMP: [15:04](https://youtu.be/2-8Hw0Myerw&t=904)
ANSWER: _Determining what is the objective truth is not always been an easy process,_ yes, not only sometimes or often, but it's always a messy process. And what's more, __we never achieve the final truth. What we discover is various truths or ideas that contain truth and solve problems thereby. But the result of solving a problem is not the absence of problems, it's a new problem. And Kuhn has seized on this feature as if it was a bad thing. This is part of the campaign of himself and many 20th century philosophers to badmouth the very concept of objective truth, even in science, let alone elsewhere. But this thing that he thinks is an indictment of science is actually the very means by which science is capable of making infinite progress.__ Because think about it, if we could achieve the final answer in everything, then science would have to come to an end and progress would be finite necessarily. But the only way that progress can be infinite, as I argue this is, is if we never reach the final truth. If all we ever do is move from a problem to a better problem, from a theory to a better theory, and so on. Never to expect the answer to be the final answer for it to solve the problem as we see it now. And the result is always a better, more beautiful, more intriguing, more useful set of problems. *IN-LINE: So philosophically, then, outside of what we can know, is there final, you say, ontological truth about nature?* Yes, that's the other half of the story. There is an objective truth, a final objective truth that, as you say, ontologically, as it were, exists. But what we do, we don't have access to final truth. All we can do is improve. And we can improve objectively. Sometimes when we think we've improved, we haven't in fact improved. And just that very concept, the idea that we can think we have improved but haven't in fact improved, you can't even realize that properly. You can't grok that properly, if I may say so, without realizing that there is an objective truth that is independent of what anyone may think. *IN-LINE: So the final grok is unattainable.* That's right.
EDITS: 
TOPICS: truth, progress, limits
STARS: 5

QUESTION: Why is the concept of sustainability misleading when it comes to the Earth and the evolution of species?
TIMESTAMP: [17:47](https://youtu.be/2-8Hw0Myerw&t=1067)
ANSWER: __The world just is unsustainable. The 99.9 percent of all species that have ever existed have been wiped out by the very earth on which they evolved. And all of our sister species were wiped out by the same environment that they grew up in. And the Great Rift Valley in Africa, where our species evolved, could hardly support any people by present-day standards. And those that it did support, it supported only in tremendous misery, like it does with nearly all species. Nature is not only red in tooth and claw, it's cruel, it's full of starvation and slavery and sickness and conflict and so on. It's only humans that can improve things. And that's what we do, but improving them only gives us ever a temporary respite from this normal state of affairs in nature of being cruel and involving suffering.__ So what we do is we improve things, we reach a new level of problems thereby. We improve those and we reach a new level of problems there. If that couldn't go on forever, then we'd be headed for a brick wall and we would go extinct like all of our predecessor species. But if it's unlimited, which I argue it is, then we can keep surviving and making our lives better, but only by a continual exercise of creativity.
EDITS: 
TOPICS: sustainability, evolution, prehistory
STARS: 4

QUESTION: What is the case for expanding our civilization beyond Earth?
TIMESTAMP: [19:35](https://youtu.be/2-8Hw0Myerw&t=1175)
ANSWER: _Regarding expanding our civilization beyond Earth,_ yes, we're going to have to. It's becoming the consensus nowadays, we're going to not leave all our eggs in one basket and colonize first other planets and then other star systems and thereby cross the galaxy. But we will also be exploring downwards into nanotechnology and deeper and deeper understanding of atoms and physical processes at the fundamental level. And in fact, the two will go together as they always have. __The question is whether the distinctively human way of existing, namely to improve things and thereby change them and thereby encounter new problems and have things get better, whether that is inherently finite or whether it's unlimited. And if it's inherently finite, then we are doomed no matter what we do. But if it's unlimited, which I argue that it is, then we may not be doomed. In that case, whether we are doomed or not depends on what decisions we make, whether we make decisions in the rational way of trying to find better explanations or whether we try irrational ways of, for example, seeking stasis such as sustainability, which I think is a very poor aim for a guiding principle for human decisions.__ *IN-LINE: Well, here's to unlimited progress then.* Yeah, I couldn't agree more.
EDITS: 
TOPICS: space colonization
STARS: 

QUESTION: How might good explanations arise in sports due to inexplicit knowledge?
TIMESTAMP: [22:08](https://youtu.be/2-8Hw0Myerw&t=1328)
ANSWER: Ah, now _David Beckham the soccer player_ definitely has good explanations, but they might be inexplicit. That is, they may not be expressed in words. What a great sportsman has is knowledge that is not necessarily expressible in words. If it were, then they could pass it on much more easily to other people. It may be only partially expressed in words. But on the other hand, if somebody is consistently better at something than other people, this is due to knowledge. And so I would have to say yes for David Beckham, but almost certainly it's inexplicit knowledge.
EDITS: 
TOPICS: good explanation, sports, inexplicit
STARS: 

QUESTION: How is business success due to knowledge and explanations?
TIMESTAMP: [22:48](https://youtu.be/2-8Hw0Myerw&t=1368)
ANSWER: _Regarding whether Richard Branson has good explanations,_ anyone who's a self-made billionaire knows stuff. I think, and it might be, again, inexplicit or it might be explicit. I think that Richard Branson certainly has a large amount of inexplicit knowledge about how to run organizations and also about how to tune products to the market. I haven't actually heard explicit theories from him, so I can't judge his explicit theories, I'm afraid. And again, if somebody does anything a lot better than other people who are trying to do it, it's because they know something, and that has got to be at the explanations at some level.
EDITS: 
TOPICS: good explanation, business
STARS: 

QUESTION: What does David Deutsch think about David Cameron's knowledge and effectiveness as the Prime Minister?
TIMESTAMP: [23:52](https://youtu.be/2-8Hw0Myerw&t=1432)
ANSWER: _Regarding whether David Cameron has good explanations,_ the jury's out there. Cameron occasionally says things that clearly are explanatory theories, and they have got him to the top first of his party and now of the country. So he's obviously got some kind of knowledge to that extent. But I think with the Prime Minister, one has to ask primarily about their explicit knowledge, whether the assertions they make in their speeches are good explanations or not. And I have certainly seen some that are, but again, with the Prime Minister, one can't tell whether he wrote them. So what one has to do with the Prime Minister is wait and see what the outcome is. Only a Prime Minister with good explanations can achieve success for the country. So we'll wait and see.
EDITS: 
TOPICS: good explanation, politics
STARS: 

