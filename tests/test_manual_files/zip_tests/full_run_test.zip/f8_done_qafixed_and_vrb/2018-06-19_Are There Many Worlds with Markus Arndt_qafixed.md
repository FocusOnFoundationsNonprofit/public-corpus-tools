## metadata
last updated: 02-10-2024 by Randy after Randy
link: https://www.youtube.com/watch?v=kNAR74SWOho
transcript source: whspmerge
length: 14:25

## content

### qa

QUESTION: What is the meaning of reality in the context of quantum mechanics?
TIMESTAMP: [1:32](https://www.youtube.com/watch?v=kNAR74SWOho&t=92)
ANSWER: _Regarding the meaning of reality in the context of quantum mechanics, some physicists_ put it in terms of "How do we make sense of the unitary evolution compared with what we see at a measurement?" and so on. I would want to start before that. I think we want to understand the world. We want to understand how the world is. And that is not necessarily what we perceive. Our perceptions are at the end of a long chain of physical processes of which themselves we only have scientific knowledge or indirect knowledge. So I would start with the question, "How do we explain quantum phenomena like interference?" Not how do we make sense of quantum theory, which gives the right prediction, but first before that, how do we explain quantum phenomena? So there's an interference process and we have interference pattern which we can see without any quantum mechanics that the result of the experiment cannot be explained by the events that we see. Now, this is not very unusual. This happens a lot in physics and ultimately every observation is made very indirectly. So we have to infer things that are not there. Although infer is the wrong word. We have to conjecture explanations. So that's where I would start.
EDITS: 
TOPICS: physics, quantum, reality
STARS: 4

QUESTION: What is the relationship of reality, information, and physics?
TIMESTAMP: [3:30](https://www.youtube.com/watch?v=kNAR74SWOho&t=210)
ANSWER: _It is_ a very interesting point about the relationship of information to reality because __many people think that the concept of information is somehow prior to physics, that the laws of information are like mathematical theorems, they must be so. Whereas I tend to the view that what information does and what it can do in the world is determined by physics and therefore in regard to physics, physics is a theory of the world, of the reality of the world, not about the information.__ There is this view that quantum mechanics only tells us what we will see and it's silent about everything else. Everything else is just mathematical formalism. But I think that ultimately leads to solipsism and it is no good philosophically. But it's even more important maybe for a physicist, it's no good for finding out what the next theory will be. If you just think a theory is predictions of experiments, then we would never have got from Kepler's theory to Newton's theory and from Newton's theory to Einstein's because they differ from each other in what in predictive terms is a tiny amount, but in explanatory terms is an enormous amount, changes our whole view of the universe.
EDITS: 
TOPICS: it-from-bit, instrumentalism, reality, information, physics
STARS: 4

QUESTION: How can we experimentally access and verify multiverse quantum theory?
TIMESTAMP: [5:23](https://www.youtube.com/watch?v=kNAR74SWOho&t=323)
ANSWER: _Regarding_ interference experiments. In an interference experiment, even with this notion of seeing things through the explanation, we only see that the, let's say the photon exists in two instances rather than that the whole world does, and when you talk about your experience at the moment, as you say, we can only probe whether an experimental outcome is caused by a single history or by multiple histories of an atom, a molecule. You, in your talks, you gave a wonderful example of very large objects from an atomic point of view, exhibiting interference of existing in more than one instance. When we have quantum computers, we will be able to have very large, very complex entities existing in superpositions. __So in principle, I suggested a long ago before this was remotely on the cards experimentally, that if we had a quantum computer on which an artificial intelligence program was running, say with human level artificial intelligence, then this entity would be able to experience interference in its own consciousness.__ *IN-LINE: Well, some people would say that your consciousness would collapse your reality.* Yes. So if that happened, that would refute the Everett interpretation, or as I would say, it would refute quantum theory. And that would be a very interesting problem. And that's one of the reasons why scaling up both the size and the complexity and the mass of phenomena that are experimentally observed, but can only be explained by quantum theory is very important. *IN-LINE: I fully agree. We need to do that.* And we just need to close the gap between that and the AI, because the AI would not be having this conversation, or at least the AI would not be able to make the argument that you just made. It would have to say, "I've only got evidence of many-worlds on the scale of my mind, but not bigger." So, and I guess that will always be true.
EDITS:
TOPICS: multiverse, quantum
STARS: 5

QUESTION: What evidence is there, short of quantum theory itself, that points toward the multiverse?
TIMESTAMP: [8:24](https://www.youtube.com/watch?v=kNAR74SWOho&t=504)
ANSWER: I think we have something slightly more than _the quantum mechanical description of the wave function_. Again, you come from theory, but I think prior to the theory, we have the experience that this thing cannot be explained by single trajectories. We don't have to believe quantum mechanics to see that. So we rule out single trajectory explanations, and that we have before we have quantum mechanics. If we didn't have quantum mechanics, it would be a mystery. We would say that simply is no explanation.
EDITS:
TOPICS: physics, quantum, multiverse
STARS: 

QUESTION: Could the concept of a multiverse actually be explained by weird folding of spacetime or existing within higher dimensions?
TIMESTAMP: [9:22](https://www.youtube.com/watch?v=kNAR74SWOho&t=562)
ANSWER: Yes is the answer. __Calling the multiverse "many universes" is a bit of a misnomer because the whole point of it is interference. And many universe, parallel universes would indicate separate universes and that these, or that these universes, that our universe splits into two every time a quantum event happens. Whereas actually it's only the, it's only the electron or the photon or something that's splitting. Now, if this can be explained in another way than by quantum theory, then another thing we know from just, without theory, with just elementary reasoning about the experiments, is that this other thing has to be immensely complicated. It's sort of two to the power of the complexity of what we see. And again, when we have fully fledged quantum computers, we will have computations going on whose results cannot be explained by any history of the computer that has it single valued. So when that number is greater than the number of atoms in the universe, which will easily be attained as soon as we have quantum computers. So yes, there could be another explanation in terms of folded universes or other dimensions or what, but those things would have to be as complicated as the many universes.__ And as some people were saying at the other Everett conference, these things would contain other instances of people or they would contain things whose shapes were the other instances of people and so on and other instances of the quantum computer, which would be interacting with our instance and so on. So it's really a matter of terminology then, whether you call that a multiverse or parallel universes or a much higher dimensional reality than in classical concepts.
EDITS: 
TOPICS: multiverse, quantum
STARS: 5

QUESTION: How does multiverse quantum theory and the existence of many copies or branches affect a person's sense of identity?
TIMESTAMP: [11:48](https://www.youtube.com/watch?v=kNAR74SWOho&t=708)
ANSWER: _Multiverse quantum theory and the many branches_ certainly has to be taken into account _in a person's view of their identity_, but logically, it's the same issue as am I the same person that I was 10 years ago or that I will be in 10 years time? If we go back to when I was a baby, I certainly was not the same person as I am today. There is a continuity between me then and me now, but that doesn't mean I'm the same person because a qua person, I have changed drastically. But the relationship between the past and the present is one kind of thing. The relationship between the present and future is a different kind of thing. The relationship between one branch, Everett branch and another is a different kind of thing. But in all cases, what makes us say that those things are real is the explanations that we have for here and now.
EDITS: 
TOPICS: identity, multiverse, quantum
STARS: 4

QUESTION: What is wrong with the conventional "shut up and calculate" attitude in science?
TIMESTAMP: [12:57](https://www.youtube.com/watch?v=kNAR74SWOho&t=777)
ANSWER: First of all, I think that attitude _of saying "shut up and calculate" or "don't talk about things you cannot see"_ involves __saying that there are certain questions about reality that you're not allowed to ask. You're allowed to ask how the experiment was prepared. You're allowed to ask what will the results be. You're not allowed to ask how were the results brought about by the preparation. So therefore it's not an explanation in my terms. And as for "shut up", that's really another way of trying to evade the consequences in terms of reality.__ Like my favorite example is of dinosaurs in the past. So there are people who say nobody ever saw a dinosaur, nobody ever will, and therefore it's just a frivolity to say that they really exist. At most we can say fossils behave as though dinosaurs existed. But no paleontologist would accept talking that way, even though there is no experimental way of disproving that manner of speaking. So, and that's because paleontologists are only interested in paleontology because they want to know what really happened. They're not, if they were interested in fossils they would be geologists.
EDITS:
TOPICS: empiricism, physics, explanation, dinosaurs
STARS: 4

