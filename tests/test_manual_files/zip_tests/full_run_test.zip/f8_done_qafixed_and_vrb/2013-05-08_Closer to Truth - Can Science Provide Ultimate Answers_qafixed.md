## metadata
last updated: 02-15-2024 by Randy after Bert dq replace after Mae (quote check)  Randy
link: https://www.youtube.com/watch?v=j65pZMkQv48
transcript source: whspmerge
length: 7:18

## content

### qa

QUESTION: What are the limits of science?
TIMESTAMP: [0:15](https://www.youtube.com/watch?v=j65pZMkQv48&t=15)
ANSWER: One of the most important limits of science is that it isn't philosophy. Science only deals with the physical world and discover regularities in the physical world and also means of controlling the physical world. So that's one limitation and what we call scientism is the purported application of science to problems that are really philosophical. Such as the question of whether animals really feel pain or not. We can tell whether animals' nerves are excited and whether their brains react to that, but whether an animal feels pain in the sense that humans do or merely reacts in the sense that a robot does, that is ultimately a matter of philosophy because it's only philosophy that can determine the criterion for science to use when trying to distinguish between those cases. So that's a limit of science. Trying to reach into philosophy is scientism.
EDITS: 
TOPICS: scientism, limits, science, philosophy
STARS: 4

QUESTION: Can science ultimately answer every question that can be answered?
TIMESTAMP: [1:50](https://www.youtube.com/watch?v=j65pZMkQv48&t=110)
ANSWER: We can't predict the future growth of knowledge. That by the way is another limitation of science. But I think it's much more likely that the thing that is omnipotent, the thing that can reach to everywhere and solve every problem is not science narrowly conceived, but reason. The quest for good explanations reaches far beyond science into all these philosophical areas.
EDITS: 
TOPICS: science, reason, limits
STARS:

QUESTION: How does one differentiate a good explanation from science?
TIMESTAMP: [2:21](https://www.youtube.com/watch?v=j65pZMkQv48&t=141)
ANSWER: Science is a special case of good explanations. It's good explanations applied to questions about the physical world.
EDITS: 
TOPICS: science, explanation
STARS:

QUESTION: Are scientific explanations the only kinds of good explanations?
TIMESTAMP: [2:33](https://www.youtube.com/watch?v=j65pZMkQv48&t=153)
ANSWER: _The theory that scientific explanations are the only kind of good explanations_ is not part of science and therefore it rules itself out.
EDITS:
TOPICS: explanation, science
STARS: 4

QUESTION: Why are empiricism, which holds that we derive all our knowledge from sensory experience, and instrumentalism, which holds that science cannot describe reality, only predict outcomes of observations, both examples of bad philosophy?
TIMESTAMP: [3:14](https://www.youtube.com/watch?v=j65pZMkQv48&t=194)
ANSWER: _Regarding empiricism and instrumentalism,_ this trope of saying that science can only deal with predictions but not with understanding what reality is usually part of a piece of bad philosophy that's trying to rule out a piece of real science, as it happens in quantum theory when people try to say that parallel universes aren't real because we can't directly see them, we can only see their results. But the thing is it doesn't work as a foundation for science, that theory. Consider for example the theory that dinosaurs existed. Now nobody will ever see a dinosaur as the creationists are never tired of pointing out, nobody has ever seen one or will ever see one, at least not the ones that we claim existed in the past. All we see are fossils. So this empiricism would say, "Science can't make any claim about dinosaurs, it can only make a claim about fossils. This fossil will be found in a stratum with this fossil but in a different stratum from this other fossil." Now this drains science of its entire purpose, which is to understand reality. Nobody would be interested in fossils if they were just patterns in stones. There are plenty of other patterns in stones and some of them are more interesting than the fossils and certainly easier to come by.
EDITS:
TOPICS: bad philosophy, empiricism, observation, instrumentalism, prediction, explanation, dinosaurs
STARS: 

QUESTION: What criterion do empiricists use to protect science from irrationality?
TIMESTAMP: [5:09](https://www.youtube.com/watch?v=j65pZMkQv48&t=309)
ANSWER: _Regarding empiricism claiming to protect science from overreach,_ this is why we have a criterion for what is or isn't scientific, namely testability. So the scope of science keeps growing as we find ways of making testable theories about things where previously we couldn't. A prime example is cosmology, which if you look in an old dictionary you will see cosmology listed as a branch of philosophy. But if you look in a modern dictionary it's listed as a branch of physics. That's an example of the totalitarian character of physics that it tends to envelop everything else. At any one moment we can tell exactly where the limit of science is using the criterion of testability, testable theories. We have testable theories of dinosaurs, so it's legitimate to talk about dinosaurs as they were hundreds of millions of years ago as well as they are now in the form of fossils. The criterion of good explanation, that an explanation should be hard to vary, implies that criterion for good science but it also tells us what is good philosophy and that is vital. In the case of empiricism it tells us that that is bad philosophy because you could rule out anything that was real by that criterion. In fact, the sense impressions that seemed like a good basis for science at the time when empiricism was invented a few hundred years ago, turn out to be highly complex things which are not observed.
EDITS: 
TOPICS: bad philosophy, empiricism, testability, dinosaurs
STARS:

QUESTION: What do we know about the limitations of science?
TIMESTAMP: [6:56](https://www.youtube.com/watch?v=j65pZMkQv48&t=416)
ANSWER: _Ultimately there are limitations to science but we can't know where they are today._ Science has limitations, reason however does not. There will be ultimate limits of science beyond which progress will only ever be made with philosophy, broadly speaking. We don't know what those are, they are almost certainly beyond the current limits of science.
EDITS:
TOPICS: limits, science, reason
STARS:

