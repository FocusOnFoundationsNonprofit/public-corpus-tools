## metadata
last updated: 02-21-2024 by Randy after Randy
link: https://youtu.be/0CwPa0tScf8
transcript source: dgwhspm
length: 8:11

## content

### qa

QUESTION: In multiverse quantum theory, how does the differentiation of universes over time relate to the concept of the arrow of time?
TIMESTAMP: [0:21](https://youtu.be/0CwPa0tScf8&t=21)
ANSWER: What's happening to them and the reason that they used to be thought of as a branching or splitting is that they become differentiated from each other. At the beginning of time, perhaps the Big Bang or whatever was the beginning of time, the universes may all have been identical, and physical processes happening in them caused them to differentiate according to the laws of motion of quantum mechanics. So the total number, as it were, remains constant but the degree of differentiation between them increases very rapidly, and that's what we call the arrow of time.
EDITS: 
TOPICS: multiverse, quantum, time
STARS: 

QUESTION: Is the total number of universes in the multiverse finite or infinite?
TIMESTAMP: [1:04](https://youtu.be/0CwPa0tScf8&t=64)
ANSWER: _Regarding the question of whether the number of universes in the multiverse is finite or infinite,_ we can't answer that question definitively because it depends on quantum gravity, which is a theory that we don't have yet. But there is very good reason to believe that the total number of different universes is finite while the actual total number of universes is infinite. So they keep dividing up among themselves and there's no limit to how finally the multiverse can subdivide itself, but the total number of distinct different universes with different contents is a finite though enormous number.
EDITS: 
TOPICS: multiverse, quantum, infinity
STARS: 

QUESTION: As different universe differentiate in the multiverse, how does this effect human experience?
TIMESTAMP: [1:51](https://youtu.be/0CwPa0tScf8&t=111)
ANSWER: _Regarding the different universes of the multiverse,_ on the gross scale, most of the elements of human experience, once they have separated in what we usually perceive as a random event like a coin toss or whatever or winning the lottery, they no longer interact, or rather their effect on each other becomes exponentially small so that it's immeasurable, but it never goes away. It is in fact always there to some very very tiny degree, but the smaller the scale you look on, the more important these interactions between different universes become, that they are what is called in quantum theory interference processes, because the universes interfere with each other.
EDITS: 
TOPICS: multiverse, interference
STARS: 

QUESTION: What is the multiverse in quantum theory?
TIMESTAMP: [2:51](https://youtu.be/0CwPa0tScf8&t=171)
ANSWER: The multiverse is the name that this theory gives to the whole of physical reality. And it is a very complex object that is not described by the normal kind of numbers that we are familiar with, like three cats, three dogs, that kind of thing. But instead, it's described by mathematical entities that describe vast numbers of these objects at the same time, in the same formalism, and their interactions with each other. *IN-LINE: nd when we select among them as they differentiate, is that a retroactive process? Because they were all there to begin with?* No, the tendency is that universes that have been identical become different. *IN-LINE: Because of the processes in each one?* Because of the processes, yes, in each one. Although really when they're identical we must regard that as a process across all of them. What's happening all the time as well though is that they rejoin. But they rejoin on a microscopic scale which adds up to, in our experience, to a different set of laws of physics that we call classical physics and which can be approximated by these numbers that take only one value at a time. So on a microscopic scale, there are these quantum mechanical type numbers that take multiple values simultaneously, and then they are approximated on the large scale by an ensemble, a lot of universes that look like classical physics and barely interact with each other.
EDITS: 
TOPICS: multiverse
STARS: 4
ORIGINAL QUESTION: Help me to understand the difference between the universe and the multiverse, in that the multiverse can have many universes in it, but has more than what's in the universe.

QUESTION: How does multiverse quantum theory address philosophical questions about identity and the nature of time,?
TIMESTAMP: [4:51](https://youtu.be/0CwPa0tScf8&t=291)
ANSWER: One of the exciting prospects about multiverse theory is that it sheds light on some rather notorious difficult problems at the foundations of physics, one of which is time. So people often ask about the multiverse, "Okay so there are lots of copies of me, which one is the real me? Which one am I? And how can there be more than one eye, since I have a unitary consciousness?" What people often don't notice is that this same question has been asked since time immemorial by philosophers wondering about time. Is the I of 10 years ago, who perhaps did something very embarrassing that I wouldn't do today, is that really me or is it not me? Or if a criminal repents, is it the same person and should that person be punished and so on? These philosophical issues are all about whether the entities at different times are the same entity or not. It turns out, amazingly enough, that in quantum gravity, we don't have a theory of quantum gravity yet, but in the approximate theories that we think might be like quantum gravity, the different times that the snapshot of the entire universe, all at different times, appear in the theory in exactly the same way that the different universes at any one time do. In fact, there's no fundamental difference between them. If we use relativistic transformations, we can transform the one into the other. And so there's no fundamental difference between different times of the same universe and different universes at the same time. *IN-LINE: That sounds remarkable. That sounds like a radical transformation of the classical Einsteinian four-dimensional block universe which sort of sits all in the same four-dimensional space.* It is radically different, although it shares of course some things in common, but we don't know how to integrate them yet. But it seems to me that this is obviously a clue to how to integrate Einstein's relativity with quantum theory, which is an unsolved problem. *IN-LINE: It's so startling that different universes in the multiverse will deal with different times of the same sorts of events.* It's not that they deal with them, it's that the different times, that is the universe yesterday is the same kind of object as an alternative universe as we might call it today. And in the way that this is described in these putative theories of quantum gravity, there is no fundamental difference between those. It's like one of them is different universes in the east-west direction and the other one is different universes in the north-south direction. *IN-LINE: But these are all existing?* They're all existing on the same basis as each other. None of them is privileged relative to the other. As you rightly say, the flow of time is an emergent property of this thing and we can't think of the multiverse as being in time, it's more that time is a feature of the multiverse.
EDITS: 
TOPICS: multiverse, time, identity
STARS: 4
