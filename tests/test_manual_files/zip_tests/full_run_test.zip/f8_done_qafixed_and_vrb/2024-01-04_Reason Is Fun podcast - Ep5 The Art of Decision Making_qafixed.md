## metadata
last updated: 01-25-2024 Created QA
link: https://open.spotify.com/episode/6ahlsGDoR4KrPi5UZWTQDf?si=7lBWFCIlT4-NZqZ6oQldoQ
transcript source: dgwhspm
summaries source: deepgram
length: 49:12

## content

### qa

QUESTION: How do the dual meanings of the word "should" reflect different aspects of decision-making and moral reasoning in everyday life?
TIMESTAMP: [1:04](https://open.spotify.com/episode/6ahlsGDoR4KrPi5UZWTQDf?si=7lBWFCIlT4-NZqZ6oQldoQ&t=64)
ANSWER: As with many words and concepts in everyday language, "should" has two pretty opposite meanings. One of them is, I could say, it's the proposed solution of a problem, namely the problem of what to do next, which is a problem faced by any creative entity. So to be creative, creativity comes from solving problems and all life is problem solving and the problem is at least two competing theories. And so in that sense, when I say "I should do so-and-so," that ought to be, should be, the conclusion of a creative process, which at the beginning did not have, had many possible outcomes. So that's one way of looking at "should." The other way of looking at "should" and if I it's often connected with other people but to keep it uniform. Let me think of it again as just being inside one mind where you're saying, to cut a long story short, you're saying "I want to do so and so, but I should, I shouldn't." So in the case of the ice cream, it would be that, "I want the ice cream, but I shouldn't." And existing culture kind of thinks that this is what morality is about, this is what life is about. As Michael Lockwood said to me once, "Morality is the theory of', let me get this right, "the theory of why you don't do what you would do if you didn't know about morality." So his idea is, if it weren't for our theories of morality, there'd be a thing that we would do, like we would do the animal thing or the base thing or the... But because we have moral theories we don't do those anyway despite in some sense wanting to do them. Now, I think that is a description of what happens when moral thinking goes wrong, it's a very bad way of characterizing moral thinking in general. *IN-LINE: What's wrong with it?* Well, it envisages a perpetual unresolvable conflict and, that's the definition of hell or something, I mean, it's never exactly that. That's oversimplification of what the prevailing view of morality is, because I think the prevailing view also includes the idea that one can want to do the moral thing. It's not quite as the same as saying one can want to be moral because according to Michael Lockwood's definition, "That want can co-exist with another want to be immoral." *IN-LINE: You said that should was something like at the end of a creative process, that's the best answer that you've got?* Well, that's the answer, which has solved the problem for the moment. *IN-LINE: In what sense is it should that thing? Why do you need the word "should" in the first place?* Because it's not a factual statement. It's not a statement, "so-and-so is true." It's a statement that, "so-and-so should be true." If it isn't true now, we'll make it true. *IN-LINE: How come you can't just say, "I want to do such and such?'* Yes, but you need an explanation. I mean, you have an explanation. You've just worked out quite possibly a complicated explanation for why you now want this. And so there's something extra. It's beyond just wants. You had wants at the beginning. At the end you have a want and you found that by considering morality. *IN-LINE: Like as though the morality is driving the want?* Yes, absolutely. It always does. That's another thing, you know, thinking it's the other way around is another of the misconceptions about morality that's built into our culture.
EDITS: 
TOPICS: morality, psychology
STARS: 

QUESTION: Is morality inbuilt into creative beings?
TIMESTAMP: [5:53](https://open.spotify.com/episode/6ahlsGDoR4KrPi5UZWTQDf?si=7lBWFCIlT4-NZqZ6oQldoQ&t=353)
ANSWER: Yes, yes, yes, _morality is inbuilt into creative beings._ And it's built into the faculty of having wants in the first place, because a human, any creative entity, has got problems, i.e. conflicting theories, conflicting ideas, conflicting wants, conflicting moralities. We think about morality in order to solve these moral problems which we have by virtue of our nature as creative beings. *IN-LINE: Ah, so one thing I see there is when you're in that inquiry, the inquiry could be one of because this is inbuilt it can be navigated through looking at, "What do I want?" And there's another way of navigating it, which is purely intellectual based on kind of the text of what this morality is supposed to be.* I think that's not quite, I wouldn't quite put it like that, although, you know, one could put it like that. Let's say you're having a vaccination and you feel the needle going in and you have an inborn tendency to wince, that is to pull your arm away. But you want the vaccination to go well. So one way you can think about this is that you've decided you should have a vaccination and therefore your want to wince should be overridden. And you should just power through and do it anyway. But I think that for most people, you know, we call people who haven't been able to be rational about this issue, we call them needle phobic or whatever. I'm very sympathetic with that. *IN-LINE: So what's happening in the resolution of this conflict? You know, somehow you're seeing this whole vision, you're saying, "Well, I want the vaccination and like, this hurts." So you have these two conflicting things, these two conflicting feelings, two conflicting wants. I want to get this injection and I don't want to get this injection.* It's often the way, by the way, if you view an apparently intractable problem just from a different angle, like I say sometimes, you go and climb a hill and look at the problem from a different vantage point. It's not that the hill is part of the solution. It's that the different perspective on the problem makes it a different problem and therefore one that maybe can be solved.
EDITS: 
TOPICS: morality, creativity, problems, conflict
STARS: 

QUESTION: What is the relationship between decisions and problem-solving according to multiverse quantum theory?
TIMESTAMP: [8:37](https://open.spotify.com/episode/6ahlsGDoR4KrPi5UZWTQDf?si=7lBWFCIlT4-NZqZ6oQldoQ&t=517)
ANSWER: So if a decision is problematic, then you can say the process of rationally reaching the right choice, making the right decision, is a process of solving a problem. But I think many decisions don't have this kind of conflict in the first place. I think they are many decisions, like I said, in the podcast with Lulie, because nowadays we think in terms of game theory and decision theory and of probabilities and utilities and that kind of this has entered the culture. It's not that old. I think it only entered the culture like after World War II. We retrospectively frame decision-making as being this game-theoretic process, which, by the way, does not include any creativity. It doesn't involve any actual solving of problems. It's all kind of mathematical. You can end up saying, "Yes I want to do A and not B because A outweighs B." That doesn't go anywhere towards solving the problem. Well, it might go some way towards it, but there you're still left with a problem. And you know, doing A when you still want to do B, may be very unpleasant, it may be traumatic. Doing A when you want to do A and no longer want to do B, that's a solution. If there was a problem, but often, you know, when we're choosing, so-called "choosing" in a restaurant from a menu what to have for dinner, it's not really accurate to say that the different meals on the menu are choices which you are weighing. You want to have dinner and you're trying to find a nice dinner to have, and then you find it and you have it. And nowhere did this resemble a scan of the menu, a construction of the utilities, a construction of the probabilities, and so on. *IN-LINE: what was the role of creativity in that? How was that different from the game theoretic approach to the same problem?* So in the game theory view, the options are fixed and the utilities are fixed. There is no game theory for how you change your utilities. They are permanently attached to the options and there's no acknowledgement that a new option can be created. I mean, it might be acknowledged in the paragraph before all the equations, but that paragraph if it's honest will say, "We are not analyzing the issue of where the preferences come from, where the utilities come from, where our estimates of the probabilities come from. We're assuming those are all given and will not change." *IN-LINE: And it's creativity that's required to introduce the new possibilities?* Yes. Yes. *IN-LINE: Now, with creativity, we could theoretically create anything, an infinite number of new options, which seems also unhelpful.* Yes. *IN-LINE: What do you suppose guides that process?* Well, it's always in response to a problem. So for a start, what guides it is we're thinking of possible candidate solutions to the problem. By the way, when one is stuck on a problem, this search for candidate solutions goes around in circles. So you keep coming back to the same thing, "What about so and so?Oh no, that doesn't work. What about this? No, that doesn't work." And then you go back to the beginning, and you have sort of cyclic thoughts. Because if it weren't so, then either you'd be spiraling upwards to and find a solution, or you'd be spiraling downwards into a state of despair, and both those things can happen, but if you're stuck, then whatever is causing this stuckness, the hangup, is creating stasis or circularity.
EDITS: 
TOPICS: psychology, problems, decisions, game theory
STARS: 

QUESTION: What exactly is a hangup in the context of problem-solving processes?
TIMESTAMP: [13:04](https://open.spotify.com/episode/6ahlsGDoR4KrPi5UZWTQDf?si=7lBWFCIlT4-NZqZ6oQldoQ&t=784)
ANSWER: _Regarding what a hangup is,_ it's a process which operates in parallel with other processes that are perhaps trying to solve problems and it sabotages them. So it sabotages, either it sabotages the creative process by or it sabotages the critical process or maybe those are both the same thing because at any rate it installs something that knocks down every... No, it's not they're not quite the same thing, knocking down creative process means criticizing absolutely everything. Whatever comes up, it's going to be criticized and by the same criterion, and it's painful. So you want to get away from that. *IN-LINE: Are hangups always kept in place by pain?* No, they might have been originally caused by pain. *IN-LINE: Always?* I think always, but you know, I don't claim to understand the human mind. If I did, I could make AGI and I can't. So it's always caused by suffering, I think. You know, I can't swear to that, but I'm guessing. It's always originally caused by suffering. But then, once it gets entrenched, it can become part of one's personality, so that one can have these circular type of thoughts without it ever actually being painful, what happens is that you're kind of fearing the pain, but that's not right either because fear is also suffering. But it's kind of, you're chronically avoiding the pain and you've succeeded in never feeling it. *IN-LINE: Fear with resistance is suffering.* Is that right? Yeah, quite possibly, yes.
EDITS: 
TOPICS: psychology, problems
STARS: 

QUESTION: How does the interaction between emotions and internal conflicts affect behavior?
TIMESTAMP: [15:07](https://open.spotify.com/episode/6ahlsGDoR4KrPi5UZWTQDf?si=7lBWFCIlT4-NZqZ6oQldoQ&t=907)
ANSWER: Okay, well, as in the case, again, as in the case of phobias, like needle phobia and so on, the ideas that are in conflict are not all explicit. They're not all of the form, you know, "I want to do A, but if I do that then this will hurt and, you know." It's not like that. It's some of the ideas are inexplicit or unconscious. Often one isn't aware of what they are or what they were but they they participate in the unconscious process that does this sabotaging thing. *IN-LINE: Would you say somatic?* I don't know. I mean perhaps you would say somatic but I don't have such a clear picture of unconscious processes or inexplicit processes. I know that they're always there and that they are essential. I also am fairly sure that no mental process is entirely conscious, entirely explicit, entirely analytical. For example, when you're speaking, some unconscious process is bringing up the words I need. I said "need" just now. Why did I say "need'? I'm not aware of the process that fetched that from memory and I don't even know why it fetched it. It just did, unconsciously. I can conjecture. If I don't like the outcome, I can conjecture what the unconscious process might have been, and I might have used a long word and it would sound awkward in a certain context so then I can go back and say, "Well, a long word sounds pompous, then I'll switch it to a short word like Winston Churchill did." *IN-LINE: And I don't want to be the kind of person who uses long words that are pompous because I don't wanna be pompous.* Exactly, except in certain situations where I do want to be pompous. __You can criticize and criticize. If something becomes problematic, you can criticize and solve the problem in principle. And the only time that this gets stuck is when there's something irrational underway as I described and that's what I call a hangup.__
EDITS: 
TOPICS: psychology, problems
STARS: 

QUESTION: What is your approach to decision-making?
TIMESTAMP: [17:38](https://open.spotify.com/episode/6ahlsGDoR4KrPi5UZWTQDf?si=7lBWFCIlT4-NZqZ6oQldoQ&t=1058)
ANSWER: __I try to avoid decision-making. It depends what you're calling decision-making. I might have a problem and I might be seeking the solution. This doesn't usually look like having an array of solutions. Usually even having one solution is pretty good. The problem is that we have no solutions.__ But I'm generally speaking, I only have one kind of thing I want. And if I have another one, it's quickly resolved and I don't have to have a policy for how to resolve them. Obviously, problem solving involves at least two things, so I solve problems, but I don't think this comes into decision making much. *IN-LINE: But somehow it is only one thing at a time and you're never encountering something that makes it feel like there's a trade-off or there's a suffering thing?* So yes, if you're talking about everyday things, then there's really no reason why they should be problematic.
EDITS: 
TOPICS: psychology, decisions
STARS: 

QUESTION: What is the major issue with Constructor Theory in relation to time?
TIMESTAMP: [18:53](https://open.spotify.com/episode/6ahlsGDoR4KrPi5UZWTQDf?si=7lBWFCIlT4-NZqZ6oQldoQ&t=1133)
ANSWER: The kind of problem I'm working on are problems to do with ideas. So I'm trying to develop Constructor Theory, and Constructor Theory has this major flaw or gap that it doesn't deal properly with time in physics and every other, almost every other, theory in physics has got time deeply built into it. And I think that for many reasons, some of them inexplicit no doubt, but for many explicit reasons, I think that Constructor Theory is either true or it's definitely the path to the truth. And yet I can't think of a way of incorporating time. I mean, actually I'm describing it, my state of mind a little earlier some days ago, so there I've got rival theories and those trying to change those rival theories produces a whole lot more rival theories and none of them are satisfactory and I'm thinking of new ones and I'm thinking of new criteria by which to judge them. In fact, one way of looking at Constructor Theory is that it is a new way of judging theories in physics, which removes these sort of inherent problems in the existing ways.
EDITS: 
TOPICS: Constructor Theory, physics, time
STARS: 

QUESTION: How can one decide where to put attention given many possibilities?
TIMESTAMP: [20:29](https://open.spotify.com/episode/6ahlsGDoR4KrPi5UZWTQDf?si=7lBWFCIlT4-NZqZ6oQldoQ&t=1229)
ANSWER: _Regarding how to decide where to put attention given many possibilities,_ each new possibility was an attempt to solve the problem or problems in the old possibilities. Now I can't describe it in as much detail as you may want because again, if I could do that in sufficient detail, I could make an AGI to do it. The reason it doesn't explode to infinity is that each of the possibilities is there for a reason. I'm hoping that it will resolve so-and-so and then I can check to see whether it resolves so-and-so or maybe half resolves it or maybe there are many maybes and each maybe is chosen with a view to it solving the existing problems. __This whole process is intensely pleasurable, it's fun. Although I'm beset by problems, that's where I want to be. That's why I don't want to do my tax return. It's so that I can have those problems.__
EDITS: 
TOPICS: fun, psychology
STARS: 

QUESTION: What motivates you in your work or study?
TIMESTAMP: [21:34](https://open.spotify.com/episode/6ahlsGDoR4KrPi5UZWTQDf?si=7lBWFCIlT4-NZqZ6oQldoQ&t=1294)
ANSWER: The fun, yeah.
EDITS: 
TOPICS: fun
STARS: 5

QUESTION: What is the connection between fun and creativity?
TIMESTAMP: [21:48](https://open.spotify.com/episode/6ahlsGDoR4KrPi5UZWTQDf?si=7lBWFCIlT4-NZqZ6oQldoQ&t=1308)
ANSWER: I think that fun, the state of mind that we call fun is intimately connected with creativity. It's un-bulked creativity. That's what fun is, I think. I mean, you know, we can only talk in very hand-waving terms about mental states and mental processes. It's very ill understood in my view.
EDITS: 
TOPICS: fun, creativity
STARS: 

QUESTION: What is the distinction between having competing wants and being in a hangup?
TIMESTAMP: [23:35](https://open.spotify.com/episode/6ahlsGDoR4KrPi5UZWTQDf?si=7lBWFCIlT4-NZqZ6oQldoQ&t=1415)
ANSWER: I just wanted to insert that having competing wants is not the same thing as being in a hangup. Competing wants, again, it's this thing that the same words can describe two opposite things, can describe two opposite states of mind. Having competing wants in itself is pleasant. It's food for thought. If all life is problem solving and if problems are competing ideas and in particular competing wants, then all life is and should be competing wants. The thing that makes it unpleasant and pathological is when there's a process underway also in one's mind that sabotages conjecture and criticism and tries to not let the mind as a whole make progress.
EDITS: 
TOPICS: psychology, problems
STARS: 

QUESTION: How does finding enjoyment or fun serve as a crucial first step in moving away from suffering and facilitating more effective problem-solving?
TIMESTAMP: [25:58](https://open.spotify.com/episode/6ahlsGDoR4KrPi5UZWTQDf?si=7lBWFCIlT4-NZqZ6oQldoQ&t=1558)
ANSWER: Absolutely _the first step out of suffering is finding the fun or enjoyment_. Because we haven't mentioned yet, because suffering is simply distracting and is therefore another thing that prevents proper thought from happening. And suffering, especially suffering that can be mechanically lessened, can be lessened by having a cup of tea or lessened by having going on a run or whatever. If it can be done mechanically, that's obviously the first thing to do. Because then you will definitely be in a better place without even having begun solving any problem. *IN-LINE: If you are suffering and you want to solve your problem of suffering, but the suffering is preventing you from being creative, what do you do? How do you feel better?* Well, if there's nothing you know of, like a cup of tea or a hug or a run or whatever, that will reduce your suffering, then you can't. You have to do it another way. But if that's available, then I think it has to be the first thing, because unlike everything else in the whole story, it can be done mechanically.
EDITS: 
TOPICS: psychology, fun, suffering
STARS: 

QUESTION: Why might people be hesitant to embrace negative emotions?
TIMESTAMP: [27:57](https://open.spotify.com/episode/6ahlsGDoR4KrPi5UZWTQDf?si=7lBWFCIlT4-NZqZ6oQldoQ&t=1677)
ANSWER: _Regarding using emotional resistance as a pathway to creativity,_ I mean, I haven't thought deeply about that kind of thing. __I suppose that the reason why people don't naturally do this is in cases where the hangup is causing suffering directly, not just from the fact that is there, but is actually hurting you like each way every time you go around the loop, it goes, "you are no good," or something, then you try and get out of it and you go around in a circle and you come back to, "you're no good," again. So the reason people don't want to embrace the process that's doing that is that they fear being poked again. So I don't know, it's not a good state to be in.__
EDITS: 
TOPICS: psychology, problems, suffering
STARS: 4

QUESTION: How do explicit theories influence the evolution of inexplicit theories?
TIMESTAMP: [29:15](https://open.spotify.com/episode/6ahlsGDoR4KrPi5UZWTQDf?si=7lBWFCIlT4-NZqZ6oQldoQ&t=1755)
ANSWER: _Regarding a situation where repeated negative experiences lead to a significant change at a critical low point,_ yeah, I can easily imagine that happening and if it happened it would be a case of explicit theories having changed the environment in which the inexplicit theories are operating and allowed them to evolve. In general, the theories of these different kinds are not conflicting by because they are contradicting each other, as it were, not usually anyway. Usually they do it indirectly by changing the environment in which, so in this case the explicit theory, "This can't go on." Well, you know, __"This is rock bottom, therefore it can't go on, therefore I can't do the usual thing, therefore I must do a different thing." If you just said that, it wouldn't make any difference to the situation, but you feel it because the way that your feelings are evolving is affected by you having reached that decision or that theory. I say I switch to theory because I always want to stress that none of these things are sources of knowledge. Or rather they're not infallible, they're not, none of them are privileged as knowing what the answer is if you don't, they could all be mistaken.__
EDITS: 
TOPICS: psychology, inexplicit, emotions
STARS: 5

QUESTION: Can emotions be considered a source of knowledge?
TIMESTAMP: [30:49](https://open.spotify.com/episode/6ahlsGDoR4KrPi5UZWTQDf?si=7lBWFCIlT4-NZqZ6oQldoQ&t=1849)
ANSWER: A fallible source of knowledge like everything else. The reasoning is also a fallible source of knowledge.
EDITS: 
TOPICS: fallibilism, emotions, reason, knowledge
STARS: 

QUESTION: What's going on when you find yourself deciding between addressing emotions and analyzing the problem?
TIMESTAMP: [34:16](https://open.spotify.com/episode/6ahlsGDoR4KrPi5UZWTQDf?si=7lBWFCIlT4-NZqZ6oQldoQ&t=2056)
ANSWER: It occurs to me, that this picture that you just painted. I'm a total noob here in this area, but you said there's your analytical side and then there's the emotion side, and you're giving the problem to one or both of them and saying that you're hoping that one of them will tell you the answer. Well, they are actually in real life, both of them are part of you. But so is the thing that's giving them the problem, yourself, when you're giving it to them. And it seems to me that the description you gave only allows two out of those three to be creative. You are just gonna sit there and wait for the answer. But I may have got hold of the wrong end of the stick in describing this. *IN-LINE: This is brilliant. Yeah, just that notion that all three are, well, would you say that all three could be creative entities?* Yes, yes, definitely. Non-creative entities are a wholly different thing. Like if your glasses don't work, and you want to see something better, then feeling better about it isn't relevant. But I'm talking about things inside the mind. And all those things inside the mind, worth calling mind, are creative.
EDITS: 
TOPICS: psychology, emotions, reason, creativity, mind
STARS: 

QUESTION: Are all entities in the human mind creative?
TIMESTAMP: [35:24](https://open.spotify.com/episode/6ahlsGDoR4KrPi5UZWTQDf?si=7lBWFCIlT4-NZqZ6oQldoQ&t=2124)
ANSWER: _Regarding if all entities in the human mind are creative,_ yes, definitely. Non-creative entities are a wholly different thing. Like if your glasses don't work, and you want to see something better, then feeling better about it isn't, it's not relevant, but I'm talking about things inside the mind. And all those things inside the mind, worth calling mind, are creative.
EDITS: 
TOPICS: psychology, mind, creativity
STARS: 

QUESTION: What is the role in the mind of the internal critical voice?
TIMESTAMP: [35:56](https://open.spotify.com/episode/6ahlsGDoR4KrPi5UZWTQDf?si=7lBWFCIlT4-NZqZ6oQldoQ&t=2156)
ANSWER: Yeah, the superego type voice. Well, I don't like it. It's a picture of an entrenched conflict between the ego and the, or even the ego and the id and the superego. They all don't like each other and are fighting, and they're all pretending to know something. And they're all fallible, in fact. It could be that none of them are right, and so on, or it could be that all of them are right but they don't realize it yet and so on. *IN-LINE: Can't the critical voice also be creative?* Yes, yes. Well, the critical voice is an anthropomorphization of a part of a person which casts them in an authoritative role, and authority is bad. So, although the authority may well be creative and may well have knowledge and may well have the answer, that doesn't mean that they're entitled to be authoritative. I've never seriously read Freud and I've only read a bit of it, and maybe this is just my interpretation of Freud, but I think his interpretation is, We're born with just an id, and then that becomes sharpened to become an ego, and then the superego forms, and that's where morality is. The id and the ego don't have morality in them. One just has wants and the other one just has calculations. And then the superego comes in with morality. *IN-LINE: When you talk about wants, when I hear that parsing of it, the id is where I see the wants as living. And when we were talking earlier, we get onto the idea of wants being the seat of morality. And so, is that in conflict with Freud's?* I think it probably is because I think he thought of all three of these things as being largely immutable. I mean, they might evolve as you get older and they might evolve with experience or something. Basically, during any period of your life, the interaction between those is what constitutes your life. And I don't think that's accurate. You know, it can't be. *IN-LINE: If they were mutable, then is it all cool?* Yes, but then you have to ask, "Mutable by what?" Then you know, this whole picture of bits of the mind that control other bits but are mutable, well what's going to mutate them? Is it yet another bit, a super super ego? Or, oh there isn't the terminology for saying an extra bit of ego that can analyze the super ego and so on ad infinitum. It's not how anything could work, it's impossible.
EDITS: 
TOPICS: psychology, mind, Freud
STARS: 

QUESTION: What is the structure and dynamics of the different parts of the mind?
TIMESTAMP: [39:29](https://open.spotify.com/episode/6ahlsGDoR4KrPi5UZWTQDf?si=7lBWFCIlT4-NZqZ6oQldoQ&t=2369)
ANSWER: _Regarding a zookeeper opening a pen analogy to the mind,_ that's a bit like what I said about different parts of the mind altering the environment in which the others are evolving. They don't directly instruct other parts of the mind. But __unlike Freud, first of all, I think there's lots of these, and also I think that they're not arranged in any kind of hierarchy. They may at one particular instant, like one of them might be affecting the others and not vice versa, but that's not built into the system. Anything can criticize anything. And you mentioned about reaching rock bottom, so that's an example of an explicit theory changing the environment in which an inexplicit theory is evolving. But I think more often it actually happens the other way around, so it's actually good to have that example just to show that both directions are possible.__ So if it were a hierarchy, then the thing at the apex of the hierarchy could never change, unless it changes automatically with your age or whatever, changes at puberty. But something being immutable is irrational and also in practice is going to sabotage problem solving because it will rule out certain conjectures and it will also rule out certain criticisms, such as of itself.
EDITS: 
TOPICS: psychology, mind, Freud
STARS: 

QUESTION: Considering parts of the mind, what guides humans towards better explanations?
TIMESTAMP: [41:08](https://open.spotify.com/episode/6ahlsGDoR4KrPi5UZWTQDf?si=7lBWFCIlT4-NZqZ6oQldoQ&t=2468)
ANSWER: Well, _the human mind does_ doesn't always _seek good explanations_. We learn language when we're babies and toddlers, and that we must be doing that by Popperian conjecture and criticism. But Popperian epistemology is not built into us in our genes. It is itself a piece of knowledge. So when it comes to something more complicated, I hesitate to say complicated because learning language is incredibly complicated, but when it comes to something less straightforward in terms of the considerations and one's wants, then it's not obvious. Popper only invented his epistemology in the 20th century, in the 19th century nobody knew it.
EDITS: 
TOPICS: psychology, mind, good explanation, Popper
STARS: 
NOTES: Original question - So amid all these parts of the mind, what is it that draws us forward toward good explanations, toward better explanations?

QUESTION: Why do humans have the propensity to learn and solve problems from birth?
TIMESTAMP: [42:17](https://open.spotify.com/episode/6ahlsGDoR4KrPi5UZWTQDf?si=7lBWFCIlT4-NZqZ6oQldoQ&t=2537)
ANSWER: Yeah, well we have problems, so we're born with problems already and we try to solve them by conjecture and criticism. So we're born with the problem of wanting food or whatever, and we also are born with theories about how to interpret some of the movements of our limbs, not all of them. So therefore, we're born with the propensity to be frustrated. So you want to reach for something and you can't reach for it. So one of the ways of making that better is to learn to control your inborn fine motor control capacities. *IN-LINE: Yeah, I love it because what I heard in there was the suffering of the kind of the annoyance of not being, not having food.* Yeah, no, that's not necessarily it. I mean, that happens when you're bulked, when you can't make progress in this problem, that's suffering. But if it's just a problem, that's enjoyable, I mean, we know that even very young children try to do things like putting blocks on top of each other and they fail and they try again. And they're enjoying that whole process. Sometimes they get frustrated and suffer, and something has gone wrong there. That's not what we're built to do. That's something that has interfered with what we're built to do. *IN-LINE: So when you say frustration, you mean like his attempts were frustrated? Not in the sense of annoyance, but in the state of like blocked.* Yes *IN-LINE: Interesting. And in that, I hear the beginning of the rock bottom.* In the bad kind of frustration.
EDITS: 
TOPICS: psychology, problems, human nature
STARS: 

QUESTION: What can be the outcome of forming bad theories about thinking?
TIMESTAMP: [44:17](https://open.spotify.com/episode/6ahlsGDoR4KrPi5UZWTQDf?si=7lBWFCIlT4-NZqZ6oQldoQ&t=2657)
ANSWER: __One of the things that happens is that you can form bad theories about thinking. For example, that thinking is not effective. That what's effective is screaming, let's say. And what's effective is hurting someone. Those theories are mistaken.__ *IN-LINE: You can learn this.* Yeah, well, you learn it, you conjecture it, and then you may be misled by misleading experiences into concluding that that's how the world is.
EDITS: 
TOPICS: psychology
STARS: 

QUESTION: Is it possible for humans to totally avoid suffering?
TIMESTAMP: [44:54](https://open.spotify.com/episode/6ahlsGDoR4KrPi5UZWTQDf?si=7lBWFCIlT4-NZqZ6oQldoQ&t=2694)
ANSWER: _Regarding whether it's possible for humans to totally avoid suffering,_ well, you know, depends. What does have to mean in that case? It is certainly within the capacity of the human mind to live a life without ever suffering. But there are things in the world that get in the way of that. And I think for young people, it's principally coercion, in the sense of other people coercing you. I think it is possible to get into a state of internal mental coercion or intractable problems mentally without being forced to from the outside, but I think that's unusual. That's not the usual problem. The object issue, the thing that is actually at stake is not very difficult. Like, you're a toddler and you want the ice cream, and there certainly is a way in which the laws of physics don't stand in the way of you getting the ice cream, it's always your parents. In cases where it is the laws of physics, you don't usually get upset, because a real evil or whatever it is, is always amenable to solution, maybe not directly, maybe not immediately. Like, you say, "Oh, we've run out. Well, can we go to the shops? Well, the shops are shut. Well, will something else do?" There's always a problem, a real problem, as a structure. Talking about anti-rational memes and I said that the idea that there is a evil spirit called a hobgoblin. *IN-LINE: This was in the memes article which everyone should read, The Evolution of Culture has been published to the internet. It's I think one of David's best writings, it's all about coercion and hangups and everything.* one of the things I remarked in that was that if there's an anti-rational meme that asserts that there's a hobgoblin that is your enemy and coming for you, then unlike for true theories, unlike for rational memes, an anti-rational meme is actually helped in its propagation if the fact that it asserts is false, because a real danger, unlike a hobgoblin, a real danger is always finite and always is to some extent tractable. You can always make yourself a bit safer from the wolf. But if it's a hobgoblin, it's defined as that you can't make yourself safe from it.
EDITS: 
TOPICS: suffering, coercion, memes, anti-rational memes
STARS: 


