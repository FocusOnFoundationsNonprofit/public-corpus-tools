## metadata
last updated: 02-12-2024 by Mae after Randy
link: https://www.youtube.com/watch?v=ncJQTYc27ME
transcript source: whspmerge
length: 1:15:25

## content

### qa

QUESTION: What is the case for optimism?
TIMESTAMP: [3:32](https://www.youtube.com/watch?v=ncJQTYc27ME&t=212)
ANSWER: I think we've been deprived of a lot more than flying cars and Mars colonies. I think civilization is currently burdened by a debilitating pessimism. Not just prophecies of doom, because they've always existed. There's something deeper. The term "technological fix" has become as pejorative as Luddite used to be. The aspiration for technological solutions is now widely regarded as naive, a fantasy that ignores the inevitability of missteps and side effects. And that naivety is labeled "optimism". Because optimism has come to mean something like the assumption that the best will happen, or probably will. And pessimism that the worst will. They're both false as general principles. No one adopts them. They're irrationalities that people accuse each other of having. Everyone classifies themselves as somewhere in the middle, perhaps admitting to a slight bias in one direction or the other, and therefore admitting to slight irrationality. But in fact, both ends of the spectrum and the middle are predictions of success or failure, maybe probabilistic, derived only from an attitude or a principle, not from explanations of why reality should match them. And prediction without explanation is prophecy, which is reliance on the supernatural, which isn't a rational attitude to planning for the future. So what is? Well, __here's the bad news. Conventional pessimism is right that civilization has no guaranteed future, nor does our species. The overwhelming majority of civilizations and species that have ever existed are now extinct, including significantly every one of our cousin species. Every species that has ever tried to survive by creating knowledge that was not in their genome. New explanatory knowledge.__ How to make clothes and fire and farming and to live the new ways of life that that enabled. That is our biological niche to survive through the exercise of creativity. And we are the last species left in that niche. For such species, stasis is not available. We conquer problems by creating knowledge, or they conquer us. So there's nothing new in our situation of all sorts of existential danger. It's undeniable that the worst can happen, because the very worst has already happened many times. So now __for the good news. All those civilizations who believed that their famines and droughts and disasters were divine punishment for their wickedness or whatever, in reality, it was just that they didn't know enough about irrigation, medicine, and so on. If the ancient Athenians had known about antibiotics or just about hygiene, they could have prevented the plague that contributed to the fall of their nascent optimistic society. And if they had, then as Carl Sagan speculated, "We might now be at the stars." And technology would be regulating trivialities like the planetary climate, as automatically as it's now regulating the temperature in this room. We know that's possible because of a momentous dichotomy that follows directly from the rejection of the supernatural. Every transformation of physical systems that is not forbidden by laws of physics is achievable given the right knowledge. And hence, the rational attitude to the future is what I call optimism, the principle of optimism, namely that all evils are caused by lack of knowledge. That isn't a prophecy of success. It's an explanation for failure.__ If we fail at anything that's physically possible, it's because of some knowledge that we fail to create. Admittedly, some of the dangers that we currently foresee are themselves side effects of knowledge creation. But trying to slow that down won't help because what do you slow down? In 1900, no one could possibly have foreseen that research in pure physics into the esoteric properties of the element uranium would, within 50 years, become the centerpiece of everyone's existential fear. Or that another half century later, the centerpiece would be carbon dioxide. In our future too, the greatest dangers will inevitably be unforeseen. And the only type of knowledge that's capable of dealing with those is fundamental knowledge of universal regularities in nature. Any area of fundamental research could suddenly become essential to our survival. Biology, engineering. In World War II, pure mathematics was. __We also need knowledge of how to structure human institutions, to retain the miraculous property of keeping civilization stable under rapid change. Traditions of criticism and error correction. And we need wealth, meaning the ability to deploy technology in practice.__ And there's a final consideration. __The world doesn't just contain optimists and pessimists, and wise and unwise technology users. It contains enemies of civilization as well. And knowledge is impartial. It can be used for good or evil. But the enemies of civilization all necessarily have one thing in common. They are wrong. And so they fear error correction and truth. And that's why they resist changes in their ideas, which makes them less creative and slower to innovate. So our defense against the existential danger from malevolent uses of technology, the only defense is speed. The good guys must use their only advantage to stay ahead.__
EDITS: 
TOPICS: optimism, pessimism, knowledge, explanation, enemies of civilization, progress
STARS: 5

QUESTION: What should we do about potential risks to humanity?
TIMESTAMP: [26:24](https://www.youtube.com/watch?v=ncJQTYc27ME&t=1584)
ANSWER: Yes, I'm surprised by how much I agree with both people who have spoken. But I think that the crucial difference is not what we fear and what might happen, but as you said, what's best to do about it? And __the optimistic view in the way I define it is that the thing to do is defense, because the bad things will happen, not only the ones we know about.__ You know, you spoke of, or Yoh Wilson said, {HERE IS NEW QUOTATIONS “Please check this out.” *** MAE - ADDED ***} "Our descendants won't forgive us for a mass extinction." Well, there are plenty of things much worse than that, that for example, the non-existence of our descendants, which would be worse than that. And things which threaten that could come up, new things that we haven't thought of. And I can't see any alternative to the argument that the defense against that is rapid progress. 
EDITS: 
TOPICS: progress, defense, X-risk
STARS: 3

QUESTION: Is giving more knowledge to those who support terrorism or deny climate change the way to deal with them?
TIMESTAMP: [31:21](https://www.youtube.com/watch?v=ncJQTYc27ME&t=1881)
ANSWER: Yes _the best way to deal with people who support terrorism or deny climate change is to give them more knowledge_, but knowledge isn't a fluid. It's not something you can pour from one person into another mechanically. It's an active process on the part of the recipient. So giving them knowledge is rather the wrong metaphor for what needs to be done. They need knowledge. We can't give it to them. So indirect methods have to be used.
EDITS: 
TOPICS: enemies of civilization, knowledge
STARS: 4
NOTES: I think Deutsch is referring to knowledge that will help them fix their bad ideas, whereas the person asking the question is thinking about technical knowledge that will empower them to enact their bad ideas.

QUESTION: Who gives us greater urge for creativity, the pessimists or the optimists?
TIMESTAMP: [32:40](https://www.youtube.com/watch?v=ncJQTYc27ME&t=1960)
ANSWER: _Regarding who gives us greater urge for creativity, the pessimists or the optimists,_ I think it's well known that you, it's hard to make progress if you think that it's impossible. So...
EDITS: 
TOPICS: pessimism, optimism, creativity
STARS: 3

QUESTION: To what extent does the advance of technology inherently cause increases in bad economic outcomes for society?
TIMESTAMP: [35:11](https://www.youtube.com/watch?v=ncJQTYc27ME&t=2111)
ANSWER: _Regarding the advance of technology and bad economic outcomes for society_,I'm not a Luddite. So I think the Luddites were mistaken, as history shows. The jobs that they thought were being lost were soon replaced. And I think that will be true forever. I think we're going to merge with the machines rather than be taken over by them. And that merging with machines began about 6,000 years ago when writing was invented. This is a continuous process. We are completely different people knowing writing than we were before that. And this will always be true. Apart from that, technology and knowledge are impartial. That's my stand.
EDITS: 
TOPICS: technology, economics, society, unemployment
STARS: 4
NOTES: See Martin Rees' response in transcript where he argues for "massive redistribution".

QUESTION: How does creativity relate to unintended positive consequences?
TIMESTAMP: [48:54](https://www.youtube.com/watch?v=ncJQTYc27ME&t=2934)
ANSWER: I think that unintended positive consequences always come as a result of creativity from the person who noticed them. You know, penicillin was discovered because of some accidental experiment which wasn't intended. But plenty of people observed mold many times in human history. It took a scientist guessing what that was about and guessing that it might have applications and then applying that and developing it and so on. So yes, accidents can be good, but the key that makes knowledge is creativity, not accident.
EDITS: 
TOPICS: creativity
STARS: 

QUESTION: How much does optimism depend on the assumption that there are or there are not fundamental limits to knowledge creation does David Deutsch's position depend on the assumption that there are no fundamental limits to knowledge creation?
TIMESTAMP: [54:24](https://www.youtube.com/watch?v=ncJQTYc27ME&t=3264)
ANSWER: My position depends entirely on there not being such limits _fundamentally to knowledge creation_. Well, 99% on there not being such limits. I think if there was a fundamental limit to the human capacity to improve things, then we're sunk as soon as we hit that limit.
EDITS: 
TOPICS: limits, knowledge, optimism
STARS: 5
NOTES: Martin Rees' answer that follows is important as an summary of an intellectual anti-progress worldview. See transcript.

QUESTION: Is there no gap between the cognitive capabilities of humans and the computational abilities of computers?
TIMESTAMP: [56:07](https://www.youtube.com/watch?v=ncJQTYc27ME&t=3367)
ANSWER: Yes _there is no gap between the cognitive capabilities of humans and the computational abilities of computers_, because cognitive abilities are just another computation. And when we merge with computers, this merge computers, I don't mean sort of cyborg science fiction thing. I mean the same sort of thing that happened when we invented writing. When we invented that we understand things via, let's say, writing down an equation on a piece of paper, which we couldn't possibly understand without paper. And so paper is just another one of those transhuman technologies which will expand, and computers are as well. It's no difference.
EDITS: 
TOPICS: computation, brain, universality
STARS: 4

QUESTION: How does humanistic knowledge fit into the enlightenment?
TIMESTAMP: [57:38](https://www.youtube.com/watch?v=ncJQTYc27ME&t=3458)
ANSWER: _Regarding how humanistic knowledge fits into the enlightenment,_ it's essential, as I said, because science alone can't possibly progress unless society is such as to be stable under what science produces. So we're going to have to create knowledge about human institutions as well forever.
EDITS: 
TOPICS: humanism, knowledge, progress, science
STARS: 4

QUESTION: What is the purpose of seeking enlightenment?
TIMESTAMP: [58:18](https://www.youtube.com/watch?v=ncJQTYc27ME&t=3498)
ANSWER: To improve the world?
EDITS: 
TOPICS: Enlightenment, progress
STARS: 4

QUESTION: What is the cost of knowledge?
TIMESTAMP: [59:28](https://www.youtube.com/watch?v=ncJQTYc27ME&t=3568)
ANSWER: _Regarding the question of what is the cost of knowledge,_ I don't think that question takes into account that knowledge is impartial. So it's not information. There's an infinite amount of information around. Most of it isn't knowledge. And even the knowledge is mostly false. So we just have to accept that. And we have to accept that it's false. So we just have to keep improving. But I repeat myself.
EDITS: 
TOPICS: knowledge, information
STARS: 

QUESTION: Question here. Roger Door, Fellow of the Society. I'd like to take up an answer to a previous question about how we tackle ISIS and other fundamentalist group in this enlightened world. And the answer you gave was knowledge. But you couldn't do it directly. It had to be done indirectly. I'm rather intrigued as to what are the indirect methods for tackling these very big issues at the present time using knowledge.
TIMESTAMP: [1:01:02](https://www.youtube.com/watch?v=ncJQTYc27ME&t=3662)
ANSWER: _Regarding the indirect knowledge needed to address enemies of civilization_ well, I don't know. I'm a physicist. I know that in the past, civilization has managed to civilize uncivilized societies. At the end of the Second World War, it was done. But most attempts to do this, and it was done spectacularly well, but most attempts to do the same thing have spectacularly failed. And I don't know why. But this is a type of knowledge that we need to have.
EDITS: 
TOPICS: enemies of civilization, knowledge, indirect knowledge
STARS: 4

QUESTION: Is there an issue of scale regarding the opposing stances in the discussion about knowledge and its application in the world?
TIMESTAMP: [1:04:42](https://www.youtube.com/watch?v=ncJQTYc27ME&t=3882)
ANSWER: _Regarding hugely improving what's happening in the developing world by proper application of existing technology and medicine, that is_ if we knew how. But we don't know how.
EDITS: 
TOPICS: poverty, knowledge, progress
STARS: 3

QUESTION: Matthew mentioned that political leaders know less about leading now than they did decades ago because of increased complexity and diversity; how does David Deutsch respond to the idea that some forms of knowledge may regress rather than progress because of technological and scientific advancements?
TIMESTAMP: [1:08:48](https://www.youtube.com/watch?v=ncJQTYc27ME&t=4128)
ANSWER: _There is a contradiction in the argument that political leaders today are less knowledgeable and capable due to societal complexity and diversity, and also_ complaining that internet billionaires have muscled in. You can't complain about that at the same time as saying that now politicians don't know enough. *IN-LINE: Well, it's because the things that they have got are a lot cleverer than democracy, for example. So that's one of the kind of challenges we're talking about.* Well, you could think of that as a democratization of power going out of the hands of government to the people. Because those billionaires get their money from people signing up to Facebook and so on, who would easily sign up to something else.
EDITS: 
TOPICS: society, knowledge
STARS: 3
NOTES: Deutsch is challenging the notion that a decline in traditional political leadership and knowledge necessarily implies an overall regression in societal knowledge or capability. He implies that the rise of new influencers, like internet billionaires, may represent a shift in where and how societal knowledge and leadership are manifested, rather than a straightforward decline in knowledge itself.

QUESTION: Can society ensure that the dissemination and acceptance of knowledge doesn't rely on trust in a few individuals, but rather on a process that universally recognizes and adopts the best explanations?
TIMESTAMP: [1:14:01](https://www.youtube.com/watch?v=ncJQTYc27ME&t=4441)
ANSWER: I also distrust the idea of scientist kings. I think Plato was very wrong about that. I'm not sure it's fair that I get the first word and the last word. So I can just say that trusting those who provide the best explanations isn't quite it. The democratization of knowledge via the best explanations would mean, you see, once a process has decided that something is the best explanation, there's no need to trust anyone. And that's really the whole point, not for knowledge to have effects. It shouldn't be filtered through any single source. So I agree with that.
EDITS: 
TOPICS:  society, knowledge, explanation
STARS: 
ALTERNATE QUESTION: What is David Deutsch's view on the notion of scientist kings and trusting individuals for the best explanations?
ALTERNATE QUESTION: What role does trust play in accepting or challenging scientific explanations and predictions about the future?

