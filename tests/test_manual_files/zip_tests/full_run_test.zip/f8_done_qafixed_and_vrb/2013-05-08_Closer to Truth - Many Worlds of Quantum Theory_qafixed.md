## metadata
last updated: 02-21-2024 by Randy after Bert dq replace after Mae (quote check only)
link: https://youtu.be/Kj2lxDf9R3Y
transcript source: dgwhspm
length: 8:38

## content

### qa

QUESTION: What is the many-worlds interpretation of quantum theory?
TIMESTAMP: [0:20](https://youtu.be/Kj2lxDf9R3Y&t=20)
ANSWER: _The so called many-worlds interpretation of quantum theory_ is the idea that the physical world that we see around us, the room, the stars, galaxies and so on, is just one tiny sliver of the whole of reality. And the whole of reality includes many such objects, many of the kinds of objects that we have traditionally thought of as the universe. And so it's sometimes called the many universes theory. I prefer to call it the multiverse theory because it contains a lot more than just those things that we used to call universes. It contains other structure as well. So the whole thing as a whole, reality as a whole, is the multiverse.
EDITS:
TOPICS: multiverse
STARS: 4

QUESTION: How can one believe the many-worlds interpretation of quantum theory given it's remarkable and astonishing claims?
TIMESTAMP: [1:07](https://youtu.be/Kj2lxDf9R3Y&t=67)
ANSWER: The reason we have to believe _multiverse quantum theory,_ if we believe anything due to science, is well really there are two paths that force us to believe that there is a multiverse. One of them is simply to ask of quantum theory, which is the deepest theory that we have as physicists, in terms of which other theories in physics are expressed, we ask, "What does this theory say about reality?" And it turns out that in the equations of quantum mechanics to express what happens in a process in the laboratory, you have to write out many paths for the apparatus, many different histories of it. And if this is applied to different histories of the laboratory as a whole, of the experimenters, of the world and so on, then that is the parallel universes interpretation. Historically that is why people first believed in parallel universes. I actually prefer a more concrete argument, which is that if you start with the experiments, if you start with a simple thing like the two slit experiment where you pass a single photon through two different slits, that's already giving you a hint of the parallel universe's kind of idea, that if you take seriously what happens in that experiment, the outcome cannot be explained by the idea that the photon passed through only one of the states or took any one path. Any one path would give a wrong answer. And the different paths affect each other. Again, if different paths affect each other, that means that different histories affect each other and so you can build the argument up into many universes.
EDITS:
TOPICS: multiverse
STARS: 4

QUESTION: How is the use of the term "multiverse" different in cosmology versus quantum theory?
TIMESTAMP: [3:40](https://youtu.be/Kj2lxDf9R3Y&t=220)
ANSWER: The cosmological multiverse theory is about universes that do not interact with each other. The only reason that cosmologists believe they exist is that they want to explain why unusual configurations of matter exist in our universe. They want to say that in most universes they don't. So that's the cosmological kind of multiverse universes that don't interact with each other. *IN-LINE: And that's not part of your thinking. You're agnostic on that, perhaps?* Yes, I don't know whether that's true or not. What I do know is that there's a lot less evidence for the existence of those than for the quantum multiverse which paradoxically have less support among physicists than the cosmological kind.
EDITS:
TOPICS: multiverse, quantum, cosmology
STARS: 

QUESTION: Do the different universes in the multiverse interact, and what significance does this interaction have?
TIMESTAMP: [4:41](https://youtu.be/Kj2lxDf9R3Y&t=281)
ANSWER: Yes _the different universes in the multiverse do interact, and_ they are in constant intimate interaction. And although the experiments that can only be explained in terms of multiverse are very hard to arrange and they require very subtle laboratory techniques. In fact, we know from the theory that practically all of our everyday experience is conditioned by multi-universe interactions. For example, matter couldn't be solid if each atom only took one path. What keeps it solid is the interactions between different instances of the same atom in different universes. That is what makes for rigidity, it's also for what makes permanent magnets, it's also the reason that we can have amplification of signals, it's the reason that we can see stars.
EDITS:
TOPICS: multiverse
STARS: 

QUESTION: Is the interpretation of quantum theory in terms of parallel universes a commonly accepted view among physicists?
TIMESTAMP: [5:36](https://youtu.be/Kj2lxDf9R3Y&t=336)
ANSWER: I think all physicists who look at these phenomena would agree that quantum theory is needed to explain those phenomena. But they would not express quantum theory in terms of parallel universes.
EDITS:
TOPICS: physics, quantum, multiverse
STARS: 

QUESTION: How would the solidity of matter be explained by multiverse quantum theory instead of the more typical explanation in terms of the exclusion principle?
TIMESTAMP: [6:02](https://youtu.be/Kj2lxDf9R3Y&t=362)
ANSWER: _Regarding how multiverse quantum theory explains phenomena, the solidity of matter_ is a good example. So if we take the exclusion principle and express it in its true quantum theoretic terms, it says that a sum of certain terms of a vast number, exponentially vast number of terms has to equal some other exponentially vast number of terms. And that is saying that each one of these things, if it represents reality, represents a different history of the atoms and they are affecting each other. *IN-LINE: When you're saying a different history, some people talk in quantum mechanics as though these are possible histories, but they don't have a basis in reality. You are claiming that they have a basis in reality? Yes. I mean, this is a dumb question, but how many are there?* There are vast numbers. So, for example, if we're talking about the number of different histories that's happening in, let's say, a cubic meter of air, then we're talking in terms of 10 to the power of 10 to the 23 different histories are all happening at the same time.
EDITS:
TOPICS: multiverse, quantum, physics
STARS: 

QUESTION: When do the different histories of the quantum multiverse occur?
TIMESTAMP: [7:37](https://youtu.be/Kj2lxDf9R3Y&t=457)
ANSWER: _The different histories of the quantum multiverse_ have existed since the Big Bang. There was an older version of the quantum multiverse in which they only appeared as branches, but that has now been abandoned and in fact we now think of it in terms of happening for all time. But remember that there's a lot more in the multiverse than just universes, and in fact universes are an emergent property of the multiverse. So some types of phenomena like human thought and the outcomes of scientific experiments are expressible in terms of universes, but a lot of other phenomena such as quantum computers or the interior of molecules are not, and for those it's the multiverse rather than individual universes.
EDITS:
TOPICS: multiverse
STARS: 4

