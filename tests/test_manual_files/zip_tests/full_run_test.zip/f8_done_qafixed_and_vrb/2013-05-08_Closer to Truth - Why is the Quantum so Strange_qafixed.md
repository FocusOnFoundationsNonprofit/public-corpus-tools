## metadata
last updated: 02-21-2024 by Randy after Bert dq replace after Randy
link: https://www.youtube.com/watch?v=mNP5w4n9sFU
transcript source: whspmerge
length: 8:44

## content

### qa

QUESTION: What can quantum computation tell us about the nature of reality?
TIMESTAMP: [0:25](https://www.youtube.com/watch?v=mNP5w4n9sFU&t=25)
ANSWER: _Regarding what quantum computation can tell us about the nature of reality,_ that's really why I'm interested in it as well. I came to this from a physics point of view, not a computation point of view. One of the things that really attracts me about the theory of quantum computation is what it tells us about what kind of thing a law of physics is. It's been a mystery to philosophers and physicists for decades, what I think Eugene Wigner called the unreasonable effectiveness of mathematics in the natural sciences. Especially when we realize that the set of computable functions, which are familiar to us, made of things like addition and multiplication and so on, from a mathematician's point of view, they form an infinitesimally tiny subset of the set of all possible mathematical relationships. And yet, physics is made entirely out of those, and if it weren't, we wouldn't be able to know any physics. __So when it became more and more obvious that computation is built into the laws of physics at a fundamental level, a lot of people immediately jumped to the conclusion, "Oh well, the reason that mathematics is useful in the physical sciences is that the world is a computer, and we are just programs running in that computer," or something like that. Or, "We're just a simulation running in a computer." Now it seems to me that that misses the whole point of the lesson of the universality of computation for physics, because it requires a notion of what is or isn't computable that is outside the physical world, so that it was set by God or something to be a certain set, and that's why our universe only instantiates that set of mathematical relationships. Well that doesn't solve the problem. You may as well have said that God set up just our universe with those relationships.__ Remove the middleman. I think the real important lesson of the universality of computation, as revealed by quantum computers to be part of physics, is that universal computers can be built within the universe. That is really the amazing thing, because however the universe was, you could imagine some kind of super computer with unknown mathematics that simulated it. But the amazing thing about our universe is that you can make an object, a computer that can simulate any physical process, that's what universality is, and this object, the set of all its possible motions, that is the set of all possible programs that could be programmed into it, is in one-one correspondence with the set of all possible motions of anything. And that is telling us something about the universe from the inside. It's telling us something about what laws of nature actually are.
EDITS:
TOPICS: computation, universality, reality, mathematics, simulation, unreasonable effectiveness, God
STARS: 5
ADDITIONAL QUESTION: What's the significance of universality of computation?

QUESTION: Why is the quantum aspect of computation important?
TIMESTAMP: [3:46](https://www.youtube.com/watch?v=mNP5w4n9sFU&t=226)
ANSWER: _Regarding why the quantum aspect of computation is important,_ when the theory of computation was first discovered by Babbage and then developed by Alan Turing during the 1930s, it wasn't realized that this was a branch of physics at all. It was invented as a branch of mathematics to study mathematical proofs. And the theory was built up from a conjecture that a certain type of abstract object, the Turing machine, could represent all things that could be computations. Now what quantum computers, and then historically what happened after that is that people began to worry that the physical world might not be able to instantiate these operations perfectly and that therefore the real world might be a weaker kind of computer than the Turing computer, that it might be an idealization. Now when we studied this more carefully, and this is where quantum computers began to come in, we found that not only can a universal computer exist physically, but it's more powerful than a Turing machine. And what the mathematicians were doing unconsciously is that when they invented these abstract objects, they were applying their intuition about physical objects. They didn't know that that's what they were doing. And because they were applying their intuition about physical objects, they got it wrong. They thought about computing, making marks of squares of paper, and then as Feynman remarked, "They thought they understood paper." But in fact paper, like everything else, obeys quantum mechanics, and the real computation in the world is quantum computation. The theory of computation is the theory of quantum computation, and that is the theory of physics. So that means that the theory of computation is irretrievably within physics because of the quantum theory of computation.
EDITS: 
TOPICS: computation, quantum, quantum computation, physics
STARS: 4

QUESTION: What are computers and computation at a deep level?
TIMESTAMP: [6:03](https://www.youtube.com/watch?v=mNP5w4n9sFU&t=363)
ANSWER: A theory of computation within any laws of physics is the theory of how you can use physical objects to represent abstract objects. So you want to represent the integers, 1, 2, 3, and you can use physical objects like fingers to say that will be 1, that's called 2, that's called 3, and so on. And __computers are ways of instantiating abstract objects and their relationships in physical objects and their motion.__ So now what happens with quantum computers is that we simply take the deepest physical theory we have, quantum theory, and we say "What kind of information processing does quantum theory in general allow and what does it not allow?" And that's the theory of quantum computation.
EDITS: 
TOPICS: computation, quantum, quantum computation
STARS: 5
ALTERNATE QUESTION: What is quantum computation briefly?
ORIGINAL QUESTION: What is, briefly, the quantum theory of computation? How does that work? How is computation and quantum theory, quantum mechanics, integrated into a quantum theory of computation?

QUESTION: What are similarities and differences between quantum computers and classical computers?
TIMESTAMP: [6:58](https://www.youtube.com/watch?v=mNP5w4n9sFU&t=418)
ANSWER: _Regarding similarities and differences between quantum computers and classical computers,_ you find a number of similarities, and we find the reasons why the Turing theory worked as well as it did, and then you find a number of dramatic differences between the quantum computers and classical computers. The one that's got the most attention is that for certain types of calculation, a quantum computer can perform it exponentially faster than any classical computer. People haven't built quantum computers yet, but we hope that they soon will. And when a quantum computer is built, a small quantum computer with a few thousand qubits, that's the quantum analog of bits, _compared to the billions of bits in our normal computers or_ even our mobile phones. In other words, a very, very comparatively weak quantum computer could perform more computations simultaneously than could be performed by the entire visible universe if it was all made into computers. In fact, when I say more, that's an understatement. Exponentially more than that. But only for certain types of computation, and that's a token of the fact that the whole notion of computation is different in quantum computers. It's not that, like with all classical computers, you can say that one computer is ten times as fast as the other. With quantum computers, they are vastly faster than classical computers for some computations, and the same for others. And interestingly, they're not slower for any computations because a quantum computer, among its abilities, is to simulate a classical computer.
EDITS: combined segments and integrated interleaving question
TOPICS: computation, quantum computation
STARS: 


